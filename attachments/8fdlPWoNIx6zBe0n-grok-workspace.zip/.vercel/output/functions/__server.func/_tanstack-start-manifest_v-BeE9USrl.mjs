//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BeE9USrl.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/$",
			"/about",
			"/appointments",
			"/contact",
			"/donate",
			"/give",
			"/privacy",
			"/resources",
			"/services",
			"/terms",
			"/visit",
			"/volunteer"
		],
		preloads: ["/assets/index-C0G17D80.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C0G17D80.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Br-lJgNt.js"]
	},
	"/$": {
		filePath: "/workspace/src/routes/$.tsx",
		children: void 0,
		preloads: ["/assets/_-n-cMiwq3.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-BVzhocmk.js"]
	},
	"/appointments": {
		filePath: "/workspace/src/routes/appointments.tsx",
		children: void 0,
		preloads: ["/assets/appointments-CNmwIllU.js", "/assets/appointments-page-B7HT7cfM.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-CNmwIllU.js", "/assets/appointments-page-B7HT7cfM.js"]
	},
	"/donate": {
		filePath: "/workspace/src/routes/donate.tsx",
		children: void 0,
		preloads: ["/assets/donate-BtHvUBCO.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-7ZjEmr2i.js"]
	},
	"/resources": {
		filePath: "/workspace/src/routes/resources.tsx",
		children: void 0,
		preloads: ["/assets/resources-D5Td3t-P.js"]
	},
	"/services": {
		filePath: "/workspace/src/routes/services.tsx",
		children: void 0,
		preloads: ["/assets/services-D_CiR3Om.js"]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-DIDnf0Qr.js"]
	},
	"/visit": {
		filePath: "/workspace/src/routes/visit.tsx",
		children: void 0,
		preloads: ["/assets/visit-DupaTXSE.js"]
	},
	"/volunteer": {
		filePath: "/workspace/src/routes/volunteer.tsx",
		children: void 0,
		preloads: ["/assets/volunteer-Bbh2Sl2q.js"]
	}
} });
//#endregion
export { tsrStartManifest };
