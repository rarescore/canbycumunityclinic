import { i as __toESM } from "../_runtime.mjs";
import { R as require_react, _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as ArrowRight, o as Phone } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-pby2H8c5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var I18nContext = (0, import_react.createContext)(null);
function I18nProvider({ children }) {
	const [lang, setLang] = (0, import_react.useState)("en");
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const saved = window.localStorage.getItem("canby-lang");
		if (saved === "es" || saved === "en") setLang(saved);
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		document.documentElement.lang = lang;
		window.localStorage.setItem("canby-lang", lang);
	}, [lang, ready]);
	const value = (0, import_react.useMemo)(() => ({
		lang,
		setLang
	}), [lang]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(I18nContext.Provider, {
		value,
		children
	});
}
function useI18n() {
	const value = (0, import_react.useContext)(I18nContext);
	if (!value) throw new Error("I18nProvider is missing");
	return value;
}
function useTx() {
	const { lang, setLang } = useI18n();
	const tx = (value) => value[lang];
	return {
		lang,
		setLang,
		tx
	};
}
var clinic = {
	name: "Canby Community Clinic",
	former: "Pura Vida Community Clinic",
	phoneDisplay: "(818) 674-4414",
	phoneTel: "+18186744414",
	emailPatients: "Info@canbycc.org",
	emailOffice: "office@canbycc.org",
	street: "7601 Canby Ave #6B",
	city: "Reseda, CA 91335",
	npi: "1518686377",
	ein: "87-1610266",
	hcaiId: "306190044",
	mapsUrl: "https://maps.google.com/?q=7601+Canby+Ave+%236B,+Reseda,+CA+91335",
	mapsEmbed: "https://maps.google.com/maps?q=7601+Canby+Ave+6B,+Reseda,+CA+91335&z=16&output=embed",
	npiUrl: "https://npiregistry.cms.hhs.gov/provider-view/1518686377",
	hcaiUrl: "https://hcai.ca.gov/facility/pura-vida-community-clinic/",
	nonprofitUrl: "https://projects.propublica.org/nonprofits/organizations/871610266"
};
var weekdayKeys = [
	"mon",
	"tue",
	"wed",
	"thu",
	"fri"
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function useOpenNow() {
	const [open, setOpen] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const read = () => {
			const parts = new Intl.DateTimeFormat("en-US", {
				timeZone: "America/Los_Angeles",
				weekday: "short",
				hour: "2-digit",
				minute: "2-digit",
				hourCycle: "h23"
			}).formatToParts(/* @__PURE__ */ new Date());
			const weekday = parts.find((part) => part.type === "weekday")?.value ?? "";
			const hour = Number(parts.find((part) => part.type === "hour")?.value ?? "0");
			const minute = Number(parts.find((part) => part.type === "minute")?.value ?? "0");
			const weekend = weekday.startsWith("Sat") || weekday.startsWith("Sun");
			const mins = hour * 60 + minute;
			setOpen(!weekend && mins >= 540 && mins < 1020);
		};
		read();
		const id = window.setInterval(read, 6e4);
		return () => window.clearInterval(id);
	}, []);
	return open;
}
function OpenStatus({ light = false }) {
	const { tx } = useTx();
	const open = useOpenNow();
	const tone = light ? "text-cream/80" : "text-muted";
	if (open === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("text-sm", tone),
		children: tx({
			en: "Weekdays, 9 AM–5 PM",
			es: "Lunes a viernes, 9 AM–5 PM"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: cn("flex flex-wrap items-center gap-x-2 gap-y-1 text-sm font-medium", light ? "text-cream" : "text-ink"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("size-2 rounded-full", open ? "bg-green" : "bg-danger"),
				"aria-hidden": true
			}),
			open ? tx({
				en: "Open now",
				es: "Abierto ahora"
			}) : tx({
				en: "Closed now",
				es: "Cerrado ahora"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("font-normal", tone),
				children: tx({
					en: "Weekdays 9 AM–5 PM",
					es: "Lunes a viernes, 9 AM–5 PM"
				})
			})
		]
	});
}
function Reveal({ children, className }) {
	const ref = (0, import_react.useRef)(null);
	const [shown, setShown] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			setShown(true);
			return;
		}
		const observer = new IntersectionObserver(([entry]) => {
			if (entry?.isIntersecting) {
				setShown(true);
				observer.disconnect();
			}
		}, { threshold: .16 });
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: cn("reveal", shown && "reveal-in", className),
		children
	});
}
function Container({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mx-auto w-full max-w-6xl px-5 md:px-8", className),
		children
	});
}
function Kicker({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs font-medium tracking-widest text-green uppercase",
		children
	});
}
var buttonClass = {
	primary: "bg-blue text-cream hover:bg-blue-deep",
	green: "bg-green text-cream hover:bg-ink",
	secondary: "bg-cream text-ink ring-1 ring-line hover:ring-ink",
	inverse: "bg-cream text-blue hover:bg-green-soft",
	quiet: "bg-transparent text-cream ring-1 ring-cream/40 hover:bg-cream/10"
};
function ActionLink({ to, href, children, variant = "primary", className, onClick }) {
	const classNames = cn("inline-flex min-h-12 items-center justify-center gap-2 rounded-lg px-5 text-base font-medium transition-colors duration-200", buttonClass[variant], className);
	if (to) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: classNames,
		onClick,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		className: classNames,
		onClick,
		children
	});
}
function CallButton({ variant = "secondary", className, onClick }) {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ActionLink, {
		href: `tel:${clinic.phoneTel}`,
		variant,
		className,
		onClick,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
				className: "size-4",
				"aria-hidden": true
			}),
			tx({
				en: "Call",
				es: "Llamar"
			}),
			" ",
			clinic.phoneDisplay
		]
	});
}
function RequestButton({ variant = "primary", className, onClick }) {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ActionLink, {
		to: "/appointments",
		variant,
		className: cn("group", className),
		onClick,
		children: [tx({
			en: "Request an appointment",
			es: "Solicitar una cita"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
			className: "size-4 transition-transform duration-200 group-hover:translate-x-0.5",
			"aria-hidden": true
		})]
	});
}
function PageIntro({ kicker, title, lede }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "border-b border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-14 md:py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: kicker }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 max-w-3xl font-serif text-4xl leading-tight text-ink md:text-6xl",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-2xl text-lg leading-relaxed text-muted",
					children: lede
				})
			]
		})
	});
}
function Photo({ src, alt, className, priority = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt,
		className,
		loading: priority ? "eager" : "lazy",
		decoding: "async"
	});
}
function IllustrativeNote({ light = false }) {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: light ? "text-xs leading-relaxed text-cream/70" : "text-xs leading-relaxed text-muted",
		children: tx({
			en: "Photographs are illustrative. They are not pictures of our building, clinicians, or patients.",
			es: "Las fotografías son ilustrativas. No son imágenes de nuestro edificio, del personal clínico ni de pacientes."
		})
	});
}
function FinalCta() {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-blue-deep text-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid gap-8 py-16 md:grid-cols-12 md:items-end md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-green-soft",
						children: tx({
							en: "Begin here",
							es: "Empiece aquí"
						})
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-serif text-4xl leading-tight md:text-5xl",
						children: tx({
							en: "Call if you can. Or leave a way for us to reach you.",
							es: "Llame si puede. O déjenos una forma de comunicarnos con usted."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-xl text-base leading-relaxed text-cream/80",
						children: tx({
							en: "A request is not a confirmed visit. We will contact you on a weekday to confirm what is available and what to bring. Please do not include symptoms, diagnoses, or insurance numbers.",
							es: "Una solicitud no es una cita confirmada. Le contactaremos en un día de semana para confirmar qué hay disponible y qué traer. No incluya síntomas, diagnósticos ni números de seguro."
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 md:col-span-5 md:items-stretch",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallButton, { variant: "inverse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestButton, { variant: "quiet" })]
			})]
		})
	});
}
function HoursTable() {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpenStatus, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "mt-5 divide-y divide-line border-y border-line",
			children: [
				{
					label: {
						en: "Monday",
						es: "Lunes"
					},
					time: {
						en: "9 AM–5 PM",
						es: "9 AM–5 PM"
					}
				},
				{
					label: {
						en: "Tuesday",
						es: "Martes"
					},
					time: {
						en: "9 AM–5 PM",
						es: "9 AM–5 PM"
					}
				},
				{
					label: {
						en: "Wednesday",
						es: "Miércoles"
					},
					time: {
						en: "9 AM–5 PM",
						es: "9 AM–5 PM"
					}
				},
				{
					label: {
						en: "Thursday",
						es: "Jueves"
					},
					time: {
						en: "9 AM–5 PM",
						es: "9 AM–5 PM"
					}
				},
				{
					label: {
						en: "Friday",
						es: "Viernes"
					},
					time: {
						en: "9 AM–5 PM",
						es: "9 AM–5 PM"
					}
				},
				{
					label: {
						en: "Saturday",
						es: "Sábado"
					},
					time: {
						en: "Closed",
						es: "Cerrado"
					},
					closed: true
				},
				{
					label: {
						en: "Sunday",
						es: "Domingo"
					},
					time: {
						en: "Closed",
						es: "Cerrado"
					},
					closed: true
				}
			].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-ink",
					children: tx(row.label)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: cn("tabular-nums", row.closed ? "text-muted" : "font-medium text-ink"),
					children: tx(row.time)
				})]
			}, row.label.en))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm leading-relaxed text-muted",
			children: tx({
				en: "This is the regular weekly schedule. Call to confirm a holiday closure before you come.",
				es: "Este es el horario semanal habitual. Llame para confirmar si hay un feriado antes de venir."
			})
		})
	] });
}
//#endregion
export { I18nProvider as a, PageIntro as c, Reveal as d, clinic as f, weekdayKeys as h, HoursTable as i, Photo as l, useTx as m, Container as n, IllustrativeNote as o, cn as p, FinalCta as r, Kicker as s, CallButton as t, RequestButton as u };
