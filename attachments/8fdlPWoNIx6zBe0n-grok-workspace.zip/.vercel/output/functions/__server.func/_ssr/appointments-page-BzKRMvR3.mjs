import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as clinic, i as HoursTable, m as useTx, n as Container, s as Kicker, t as CallButton } from "./ui-pby2H8c5.mjs";
import { r as AppointmentForm } from "./router-DgWbPDCs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/appointments-page-BzKRMvR3.js
var import_jsx_runtime = require_jsx_runtime();
function AppointmentsPage() {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
		className: "grid gap-12 py-14 md:py-20 lg:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lg:col-span-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: tx({
					en: "Appointments",
					es: "Citas"
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-serif text-4xl leading-tight md:text-5xl",
					children: tx({
						en: "The phone is the surest way to be seen.",
						es: "El teléfono es la forma más segura de ser atendido."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 leading-relaxed text-muted",
					children: tx({
						en: "Call on a weekday and we can tell you, in the same conversation, whether we can see you, what to bring, and what the visit may cost. If you cannot call, the form prepares an email with scheduling details only.",
						es: "Llame en un día de semana y, en la misma conversación, le diremos si podemos atenderle, qué traer y cuánto puede costar la visita. Si no puede llamar, el formulario prepara un correo solo con datos para programar."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallButton, {
						variant: "primary",
						className: "w-full sm:w-auto"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoursTable, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: "contact",
					className: "mt-8 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "border border-line bg-cream p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-medium",
								children: tx({
									en: "Patients and appointments",
									es: "Pacientes y citas"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "mt-2 inline-flex min-h-11 items-center font-medium text-blue",
								href: `mailto:${clinic.emailPatients}`,
								children: clinic.emailPatients
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-muted",
								children: tx({
									en: "Use this address for a scheduling request or a general question about becoming a patient.",
									es: "Use esta dirección para pedir una cita o hacer una pregunta general sobre cómo ser paciente."
								})
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "border border-line bg-cream p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-medium",
								children: tx({
									en: "Office and administration",
									es: "Oficina y administración"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "mt-2 inline-flex min-h-11 items-center font-medium text-blue",
								href: `mailto:${clinic.emailOffice}`,
								children: clinic.emailOffice
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-muted",
								children: tx({
									en: "Volunteers, donations, vendors, and other office matters. Not for medical details.",
									es: "Voluntarios, donaciones, proveedores y otros asuntos de oficina. No para datos médicos."
								})
							})
						]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lg:col-span-7",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-3xl",
					children: tx({
						en: "Request a callback",
						es: "Pida que le llamemos"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 mb-6 text-sm leading-relaxed text-muted",
					children: tx({
						en: "We ask only for what we need to contact you and suggest a time. The form does not store your information and it is not a medical record. A request is not a confirmed appointment.",
						es: "Pedimos solo lo necesario para contactarle y proponer una hora. El formulario no guarda su información y no es un expediente médico. Una solicitud no es una cita confirmada."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppointmentForm, {})
			]
		})]
	}) });
}
//#endregion
export { AppointmentsPage as t };
