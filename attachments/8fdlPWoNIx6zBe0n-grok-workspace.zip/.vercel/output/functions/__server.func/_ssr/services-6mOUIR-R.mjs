import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as PageIntro, f as clinic, l as Photo, m as useTx, n as Container, r as FinalCta, s as Kicker, t as CallButton, u as RequestButton } from "./ui-pby2H8c5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-6mOUIR-R.js
var import_jsx_runtime = require_jsx_runtime();
var items = [
	{
		title: {
			en: "Primary care",
			es: "Atención primaria"
		},
		body: {
			en: "Often the first place to discuss a new concern, follow a stable condition, review medicines, and decide whether a test or a referral is needed.",
			es: "Suele ser el primer lugar para hablar de un problema nuevo, dar seguimiento a una condición estable, revisar medicamentos y decidir si hace falta una prueba o una referencia."
		},
		points: [
			{
				en: "A conversation about your main concern, history, and medicines",
				es: "Una conversación sobre su motivo principal, su historia y sus medicamentos"
			},
			{
				en: "Basic measurements — blood pressure, pulse, weight, or temperature — when they help",
				es: "Medidas básicas — presión, pulso, peso o temperatura — cuando ayudan"
			},
			{
				en: "A focused exam, and a plan for treatment, testing, follow-up, or referral",
				es: "Un examen enfocado y un plan de tratamiento, pruebas, seguimiento o referencia"
			}
		]
	},
	{
		title: {
			en: "Preventive screenings",
			es: "Evaluaciones preventivas"
		},
		body: {
			en: "Blood pressure checks, diabetes risk assessment, and a discussion of preventive care that fits your age and history. Screening is not the same as a diagnosis.",
			es: "Control de presión, evaluación del riesgo de diabetes y una conversación sobre prevención según su edad e historia. Una evaluación no es lo mismo que un diagnóstico."
		},
		points: [{
			en: "Useful if you have not had a recent check or you are unsure where to begin",
			es: "Útil si no ha tenido una revisión reciente o no sabe por dónde empezar"
		}, {
			en: "The clinic decides whether a concern can be addressed here or needs another level of care",
			es: "La clínica decide si un problema se puede atender aquí o necesita otro nivel de atención"
		}]
	},
	{
		title: {
			en: "Diagnostic and lab support",
			es: "Apoyo diagnóstico y de laboratorio"
		},
		body: {
			en: "The clinic may help coordinate basic diagnostic tests or laboratory work when it is clinically appropriate. Availability, outside fees, and follow-up are confirmed before testing.",
			es: "La clínica puede ayudar a coordinar pruebas diagnósticas o de laboratorio básicas cuando es clínicamente apropiado. La disponibilidad, los costos externos y el seguimiento se confirman antes."
		},
		points: [{
			en: "Do not assume a test is done on site or without a fee",
			es: "No suponga que una prueba se hace en el lugar o sin costo"
		}]
	},
	{
		title: {
			en: "Medication assistance",
			es: "Ayuda con medicamentos"
		},
		body: {
			en: "Patients may get help understanding a prescription or accessing certain medications. Availability changes. The clinic cannot promise that every medicine will be provided.",
			es: "Los pacientes pueden recibir ayuda para entender una receta o acceder a ciertos medicamentos. La disponibilidad cambia. La clínica no puede prometer que todo medicamento se entregará."
		},
		points: [{
			en: "Bring the bottles, or a written list, so the review is accurate",
			es: "Traiga los frascos o una lista escrita para que la revisión sea precisa"
		}]
	},
	{
		title: {
			en: "Health education",
			es: "Educación en salud"
		},
		body: {
			en: "Clear guidance about prevention, medicines, results, daily routines, and the steps after a visit. Education supports a plan. It does not replace one.",
			es: "Orientación clara sobre prevención, medicamentos, resultados, rutinas y los pasos después de la visita. La educación apoya un plan. No lo reemplaza."
		},
		points: [{
			en: "Ask for the explanation in English or Spanish",
			es: "Pida la explicación en inglés o en español"
		}]
	},
	{
		title: {
			en: "Community resource navigation",
			es: "Orientación a recursos comunitarios"
		},
		body: {
			en: "When the clinic cannot provide a service directly, staff may help you identify a public program, a specialist, or another community resource.",
			es: "Cuando la clínica no puede ofrecer un servicio directamente, el personal puede ayudarle a identificar un programa público, un especialista u otro recurso comunitario."
		},
		points: [{
			en: "This is navigation, not a guarantee of enrollment or a covered benefit",
			es: "Es orientación, no una garantía de inscripción ni de un beneficio cubierto"
		}]
	}
];
function ServicesPage() {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			kicker: tx({
				en: "Services",
				es: "Servicios"
			}),
			title: tx({
				en: "Care for the problems that keep people from starting.",
				es: "Atención para los problemas que impiden empezar."
			}),
			lede: tx({
				en: "Primary care, prevention, help with tests and medicines, and a clear next step. Every service below depends on clinical availability, volunteer staffing, eligibility, and the resources on the day of care.",
				es: "Atención primaria, prevención, ayuda con pruebas y medicamentos, y un siguiente paso claro. Cada servicio depende de la disponibilidad clínica, el personal voluntario, la elegibilidad y los recursos del día."
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid items-center gap-8 py-12 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
				src: "/media/pressure.jpg",
				alt: tx({
					en: "A blood pressure cuff on a patient’s arm. Illustrative photograph.",
					es: "Un manguito de presión en el brazo de un paciente. Fotografía ilustrativa."
				}),
				className: "aspect-still w-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-blue-soft p-6 md:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: tx({
						en: "Before you request care",
						es: "Antes de pedir atención"
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 leading-relaxed text-ink",
						children: tx({
							en: `Call ${clinic.phoneDisplay} and ask whether the service is available, what eligibility looks like right now, and what to bring. Do not assume a visit is free. Do not send records or medical details through this website.`,
							es: `Llame al ${clinic.phoneDisplay} y pregunte si el servicio está disponible, cómo es la elegibilidad ahora y qué traer. No suponga que la visita es gratuita. No envíe expedientes ni datos médicos por este sitio.`
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallButton, { variant: "primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestButton, { variant: "secondary" })]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Container, {
			className: "pb-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y divide-line border-y border-line",
				children: items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "grid gap-6 py-10 md:grid-cols-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-serif text-3xl text-green md:col-span-2",
							children: ["0", index + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "md:col-span-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-3xl",
								children: tx(item.title)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "leading-relaxed text-muted",
								children: tx(item.body)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 space-y-2",
								children: item.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "border-l-2 border-green pl-3 text-sm leading-relaxed text-ink",
									children: tx(point)
								}, point.en))
							})]
						})
					]
				}, item.title.en))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
//#endregion
export { ServicesPage as component };
