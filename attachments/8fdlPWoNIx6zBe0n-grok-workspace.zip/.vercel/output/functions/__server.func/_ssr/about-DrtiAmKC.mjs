import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as PageIntro, f as clinic, l as Photo, m as useTx, n as Container, r as FinalCta } from "./ui-pby2H8c5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-DrtiAmKC.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	const { tx } = useTx();
	const records = [
		{
			title: {
				en: "NPI registry",
				es: "Registro NPI"
			},
			body: {
				en: `National Provider Identifier ${clinic.npi}. The organization is registered as a clinic/center. The record lists ${clinic.street}, Reseda.`,
				es: `Identificador nacional de proveedor ${clinic.npi}. La organización está registrada como clínica. El registro indica ${clinic.street}, Reseda.`
			},
			href: clinic.npiUrl,
			link: {
				en: "Look up the NPI",
				es: "Consultar el NPI"
			}
		},
		{
			title: {
				en: "California HCAI",
				es: "HCAI de California"
			},
			body: {
				en: `The state facility finder lists ${clinic.former} at 7601 Canby Ave, Reseda, as an open community clinic. Facility ID ${clinic.hcaiId}. The clinic now uses the name Canby Community Clinic.`,
				es: `El buscador estatal de centros lista a ${clinic.former} en 7601 Canby Ave, Reseda, como clínica comunitaria abierta. ID de centro ${clinic.hcaiId}. La clínica ahora usa el nombre Canby Community Clinic.`
			},
			href: clinic.hcaiUrl,
			link: {
				en: "View the HCAI listing",
				es: "Ver el listado de HCAI"
			}
		},
		{
			title: {
				en: "Nonprofit filings",
				es: "Declaraciones sin fines de lucro"
			},
			body: {
				en: `Canby Community Clinic Inc., EIN ${clinic.ein}, is a 501(c)(3) formed in 2022. Public filings describe a community clinic serving families in Reseda. Confirm the legal payee and current tax status with the office before you claim a deduction.`,
				es: `Canby Community Clinic Inc., EIN ${clinic.ein}, es una 501(c)(3) formada en 2022. Las declaraciones públicas describen una clínica comunitaria que atiende a familias en Reseda. Confirme el beneficiario legal y la situación fiscal con la oficina antes de deducir un donativo.`
			},
			href: clinic.nonprofitUrl,
			link: {
				en: "See public filings",
				es: "Ver declaraciones públicas"
			}
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			kicker: tx({
				en: "About the clinic",
				es: "Sobre la clínica"
			}),
			title: tx({
				en: "Formerly Pura Vida. Still a clinic for people who have had trouble getting in.",
				es: "Antes Pura Vida. Sigue siendo una clínica para quien ha tenido dificultad para entrar."
			}),
			lede: tx({
				en: "Canby Community Clinic connects people facing barriers to care with practical medical support, preventive services, health education, and community resources. The work is done by licensed professionals, clinical volunteers, interpreters, and neighbors.",
				es: "Canby Community Clinic conecta a personas que enfrentan barreras con apoyo médico práctico, servicios preventivos, educación en salud y recursos comunitarios. El trabajo lo hacen profesionales con licencia, voluntarios clínicos, intérpretes y vecinos."
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid items-center gap-10 py-14 md:grid-cols-2 md:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
				src: "/media/valley.jpg",
				alt: tx({
					en: "Late-afternoon light on a San Fernando Valley street. Illustrative photograph, not our building.",
					es: "Luz de tarde en una calle del Valle de San Fernando. Fotografía ilustrativa, no nuestro edificio."
				}),
				className: "aspect-video w-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5 leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-3xl text-ink",
						children: tx({
							en: "Why the clinic exists",
							es: "Por qué existe la clínica"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: tx({
						en: "Cost, insurance status, language, transportation, and the difficulty of finding a timely appointment keep people from basic care. The clinic tries to lower those barriers with scheduled visits, volunteer help, and community outreach.",
						es: "El costo, el seguro, el idioma, el transporte y la dificultad de encontrar una cita a tiempo alejan a la gente de la atención básica. La clínica intenta bajar esas barreras con visitas programadas, ayuda voluntaria y alcance comunitario."
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: tx({
						en: "Care is a mix of scheduled patient visits and the people who make those visits possible. What can be offered depends on staffing and resources. That is why we ask you to call before you come.",
						es: "La atención combina visitas programadas y las personas que las hacen posibles. Lo que se puede ofrecer depende del personal y los recursos. Por eso pedimos que llame antes de venir."
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: tx({
						en: "We welcome patients without regard to race, color, national origin, age, disability, sex, sexual orientation, gender identity, language, or insurance status. If you need help with access or interpretation, say so when you call. We will tell you plainly what we can arrange.",
						es: "Recibimos pacientes sin distinción de raza, color, origen nacional, edad, discapacidad, sexo, orientación sexual, identidad de género, idioma o situación de seguro. Si necesita ayuda con el acceso o la interpretación, dígalo al llamar. Le diremos con claridad qué podemos organizar."
					}) })
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "py-14 md:py-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-4xl",
						children: tx({
							en: "Public record, not a trophy case",
							es: "Registro público, no una vitrina"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-2xl leading-relaxed text-muted",
						children: tx({
							en: "We do not publish clinician names, awards, patient stories, prices, or insurance lists on this website unless they are verified and authorized. The items below are public registrations you can open yourself.",
							es: "No publicamos nombres de clínicos, premios, historias de pacientes, precios ni listas de seguros en este sitio salvo que estén verificados y autorizados. Lo de abajo son registros públicos que usted puede abrir."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-4 md:grid-cols-3",
						children: records.map((record) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "flex flex-col border border-line bg-paper p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-serif text-2xl",
									children: tx(record.title)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 flex-1 text-sm leading-relaxed text-muted",
									children: tx(record.body)
								}),
								record.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: record.href,
									target: "_blank",
									rel: "noreferrer",
									className: "mt-4 inline-flex min-h-11 items-center text-sm font-medium text-blue",
									children: tx(record.link)
								}) : null
							]
						}, record.title.en))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
//#endregion
export { AboutPage as component };
