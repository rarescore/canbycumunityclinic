import { i as __toESM } from "../_runtime.mjs";
import { R as require_react, _ as Link, f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent, v as useRouter, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TriangleAlert, s as Menu, t as X } from "../_libs/lucide-react.mjs";
import { a as I18nProvider, c as PageIntro, f as clinic, h as weekdayKeys, m as useTx, n as Container, p as cn, t as CallButton, u as RequestButton } from "./ui-pby2H8c5.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/forms-CZ3d3yxi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var days = [
	{
		key: "mon",
		label: {
			en: "Mon",
			es: "Lun"
		}
	},
	{
		key: "tue",
		label: {
			en: "Tue",
			es: "Mar"
		}
	},
	{
		key: "wed",
		label: {
			en: "Wed",
			es: "Mié"
		}
	},
	{
		key: "thu",
		label: {
			en: "Thu",
			es: "Jue"
		}
	},
	{
		key: "fri",
		label: {
			en: "Fri",
			es: "Vie"
		}
	}
];
var dayName = {
	mon: "Monday",
	tue: "Tuesday",
	wed: "Wednesday",
	thu: "Thursday",
	fri: "Friday"
};
var emptyAppt = {
	first: "",
	last: "",
	phone: "",
	email: "",
	contact: "",
	patient: "",
	language: "",
	otherLanguage: "",
	days: [],
	time: "",
	note: "",
	ack: false,
	website: ""
};
function Field({ label, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium text-ink",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2",
				children
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-sm text-danger",
				children: error
			}) : null
		]
	});
}
var inputClass = "min-h-12 w-full rounded-lg border border-line bg-cream px-3 text-base text-ink outline-none placeholder:text-muted/70";
function AppointmentForm() {
	const { tx, lang } = useTx();
	const [state, setState] = (0, import_react.useState)(emptyAppt);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [ready, setReady] = (0, import_react.useState)("");
	const copyText = (0, import_react.useMemo)(() => ready ? decodeMailto(ready) : "", [ready]);
	function update(key, value) {
		setState((current) => ({
			...current,
			[key]: value
		}));
	}
	function toggleDay(day) {
		setState((current) => ({
			...current,
			days: current.days.includes(day) ? current.days.filter((item) => item !== day) : [...current.days, day]
		}));
	}
	function onSubmit(event) {
		event.preventDefault();
		const next = validateAppt(state, tx);
		setErrors(next);
		if (Object.keys(next).length) return;
		if (state.website.trim()) {
			setReady("blocked");
			return;
		}
		const href = buildAppointmentMailto(state);
		setReady(href);
		window.location.href = href;
	}
	if (ready && ready !== "blocked") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-green-soft p-6 md:p-8",
		role: "status",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-3xl text-ink",
				children: tx({
					en: "Your email app should open now.",
					es: "Su correo debería abrirse ahora."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 leading-relaxed text-ink",
				children: tx({
					en: `Nothing from this form is saved on the website. The message is addressed to ${clinic.emailPatients}. If email does not open, call ${clinic.phoneDisplay} — that is the fastest way to be seen. A request is not a confirmed appointment.`,
					es: `Nada de este formulario se guarda en el sitio. El mensaje va dirigido a ${clinic.emailPatients}. Si el correo no se abre, llame al ${clinic.phoneDisplay}: es la forma más rápida de ser atendido. Una solicitud no es una cita confirmada.`
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: ready,
					className: "inline-flex min-h-12 items-center justify-center rounded-lg bg-blue px-5 font-medium text-cream",
					children: tx({
						en: "Open the email again",
						es: "Abrir el correo de nuevo"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex min-h-12 items-center justify-center rounded-lg bg-cream px-5 font-medium text-ink ring-1 ring-line",
					onClick: () => {
						navigator.clipboard?.writeText(copyText);
					},
					children: tx({
						en: "Copy the message",
						es: "Copiar el mensaje"
					})
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "rounded-lg border border-line bg-cream p-5 md:p-8",
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: tx({
							en: "First name",
							es: "Nombre"
						}),
						error: errors.first,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							autoComplete: "given-name",
							value: state.first,
							onChange: (event) => update("first", event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: tx({
							en: "Last name",
							es: "Apellido"
						}),
						error: errors.last,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							autoComplete: "family-name",
							value: state.last,
							onChange: (event) => update("last", event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: tx({
							en: "Phone",
							es: "Teléfono"
						}),
						error: errors.phone,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							autoComplete: "tel",
							inputMode: "tel",
							value: state.phone,
							onChange: (event) => update("phone", event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: tx({
							en: "Email",
							es: "Correo"
						}),
						error: errors.email,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							autoComplete: "email",
							inputMode: "email",
							value: state.email,
							onChange: (event) => update("email", event.target.value)
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-sm font-medium text-ink",
						children: tx({
							en: "Best way to reach you",
							es: "Mejor forma de contactarle"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-2 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							pressed: state.contact === "phone",
							onClick: () => update("contact", "phone"),
							label: tx({
								en: "Phone",
								es: "Teléfono"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							pressed: state.contact === "email",
							onClick: () => update("contact", "email"),
							label: tx({
								en: "Email",
								es: "Correo"
							})
						})]
					}),
					errors.contact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-danger",
						children: errors.contact
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-sm font-medium text-ink",
						children: tx({
							en: "Have you been here before?",
							es: "¿Ha venido antes?"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-2 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							pressed: state.patient === "new",
							onClick: () => update("patient", "new"),
							label: tx({
								en: "New patient",
								es: "Paciente nuevo"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							pressed: state.patient === "returning",
							onClick: () => update("patient", "returning"),
							label: tx({
								en: "I have been seen here",
								es: "Ya me han atendido aquí"
							})
						})]
					}),
					errors.patient ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-danger",
						children: errors.patient
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-sm font-medium text-ink",
						children: tx({
							en: "Language for the visit",
							es: "Idioma para la visita"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-2 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								pressed: state.language === "english",
								onClick: () => update("language", "english"),
								label: tx({
									en: "English",
									es: "Inglés"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								pressed: state.language === "spanish",
								onClick: () => update("language", "spanish"),
								label: tx({
									en: "Spanish",
									es: "Español"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								pressed: state.language === "other",
								onClick: () => update("language", "other"),
								label: tx({
									en: "Other",
									es: "Otro"
								})
							})
						]
					}),
					state.language === "other" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: cn(inputClass, "mt-3"),
						maxLength: 40,
						placeholder: tx({
							en: "Which language?",
							es: "¿Qué idioma?"
						}),
						value: state.otherLanguage,
						onChange: (event) => update("otherLanguage", event.target.value)
					}) : null,
					errors.language ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-danger",
						children: errors.language
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-sm font-medium text-ink",
						children: tx({
							en: "Preferred weekdays",
							es: "Días de semana que prefiere"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-5 gap-2",
						children: days.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": state.days.includes(day.key),
							onClick: () => toggleDay(day.key),
							className: cn("min-h-12 rounded-lg text-sm font-medium ring-1", state.days.includes(day.key) ? "bg-blue text-cream ring-blue" : "bg-paper text-ink ring-line"),
							children: tx(day.label)
						}, day.key))
					}),
					errors.days ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-danger",
						children: errors.days
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-sm font-medium text-ink",
						children: tx({
							en: "Time of day",
							es: "Hora del día"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid gap-2 sm:grid-cols-3",
						children: [
							["morning", {
								en: "Morning",
								es: "Mañana"
							}],
							["afternoon", {
								en: "Afternoon",
								es: "Tarde"
							}],
							["either", {
								en: "Either",
								es: "Cualquiera"
							}]
						].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							pressed: state.time === key,
							onClick: () => update("time", key),
							label: tx(label)
						}, key))
					}),
					errors.time ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-danger",
						children: errors.time
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: tx({
					en: "Scheduling note, optional",
					es: "Nota para programar, opcional"
				}),
				error: errors.note,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: cn(inputClass, "min-h-28 py-3"),
					maxLength: 280,
					value: state.note,
					onChange: (event) => update("note", event.target.value),
					placeholder: tx({
						en: "Example: weekday mornings after 10. Do not describe symptoms or medicines.",
						es: "Ejemplo: mañanas entre semana después de las 10. No describa síntomas ni medicamentos."
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-1 block text-xs text-muted",
					children: [state.note.length, "/280"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sr-only",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Website", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					tabIndex: -1,
					autoComplete: "off",
					value: state.website,
					onChange: (event) => update("website", event.target.value)
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-6 flex items-start gap-3 text-sm leading-relaxed text-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "mt-1 size-5 accent-blue",
					checked: state.ack,
					onChange: (event) => update("ack", event.target.checked)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tx({
					en: "I understand this form only arranges a callback. I will not include symptoms, diagnoses, medications, test results, insurance numbers, or other medical details. Ordinary email is not secure for that information.",
					es: "Entiendo que este formulario solo sirve para que me llamen. No incluiré síntomas, diagnósticos, medicamentos, resultados, números de seguro ni otros datos médicos. El correo ordinario no es seguro para esa información."
				}) })]
			}),
			errors.ack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-danger",
				children: errors.ack
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "mt-6 inline-flex min-h-12 w-full items-center justify-center rounded-lg bg-blue px-5 font-medium text-cream hover:bg-blue-deep sm:w-auto",
				children: tx({
					en: "Prepare my email request",
					es: "Preparar mi solicitud por correo"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs leading-relaxed text-muted",
				children: lang === "es" ? `Se abrirá su correo dirigido a ${clinic.emailPatients}. El sitio no guarda estos datos.` : `This opens your email to ${clinic.emailPatients}. The website does not store this information.`
			})
		]
	});
}
function Choice({ pressed, onClick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": pressed,
		onClick,
		className: cn("min-h-12 rounded-lg px-3 text-sm font-medium ring-1", pressed ? "bg-blue text-cream ring-blue" : "bg-paper text-ink ring-line"),
		children: label
	});
}
function validateAppt(state, tx) {
	const errors = {};
	const required = tx({
		en: "This is required.",
		es: "Esto es necesario."
	});
	if (!state.first.trim()) errors.first = required;
	if (!state.last.trim()) errors.last = required;
	if (!/^[+()\d\s.-]{7,20}$/.test(state.phone.trim())) errors.phone = tx({
		en: "Enter a phone number we can call.",
		es: "Escriba un teléfono al que podamos llamar."
	});
	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(state.email.trim())) errors.email = tx({
		en: "Enter a valid email.",
		es: "Escriba un correo válido."
	});
	if (!state.contact) errors.contact = required;
	if (!state.patient) errors.patient = required;
	if (!state.language) errors.language = required;
	if (state.language === "other" && !state.otherLanguage.trim()) errors.language = required;
	if (!state.days.length) errors.days = tx({
		en: "Choose at least one weekday.",
		es: "Elija al menos un día."
	});
	if (!state.time) errors.time = required;
	if (state.note.length > 280) errors.note = required;
	if (!state.ack) errors.ack = tx({
		en: "Please confirm you will not include medical details.",
		es: "Confirme que no incluirá datos médicos."
	});
	return errors;
}
function buildAppointmentMailto(state) {
	const language = state.language === "other" ? `Other: ${state.otherLanguage.trim()}` : state.language === "spanish" ? "Spanish" : "English";
	const body = [
		"Appointment request for Canby Community Clinic",
		"Scheduling details only — no medical information.",
		"",
		`Name: ${state.first.trim()} ${state.last.trim()}`,
		`Phone: ${state.phone.trim()}`,
		`Email: ${state.email.trim()}`,
		`Preferred contact: ${state.contact}`,
		`Patient: ${state.patient === "new" ? "New" : "Returning"}`,
		`Language: ${language}`,
		`Preferred days: ${weekdayKeys.filter((day) => state.days.includes(day)).map((day) => dayName[day]).join(", ")}`,
		`Time of day: ${state.time}`,
		`Scheduling note: ${state.note.trim() || "(none)"}`,
		"",
		"Sent from the clinic website. The sender was asked not to include symptoms, diagnoses, medications, test results, or insurance numbers."
	].join("\n");
	return `mailto:${clinic.emailPatients}?subject=${encodeURIComponent("Appointment request")}&body=${encodeURIComponent(body)}`;
}
function decodeMailto(href) {
	const body = href.split("body=")[1] ?? "";
	try {
		return decodeURIComponent(body);
	} catch {
		return body;
	}
}
function MailReady({ href, title, body }) {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-green-soft p-6",
		role: "status",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-3xl text-ink",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 leading-relaxed text-muted",
				children: body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href,
				className: "mt-5 inline-flex min-h-12 items-center font-medium text-blue",
				children: tx({
					en: "Open the email again",
					es: "Abrir el correo de nuevo"
				})
			})
		]
	});
}
function Chip({ pressed, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": pressed,
		onClick,
		className: cn("min-h-12 rounded-lg px-3 text-left text-sm font-medium ring-1", pressed ? "bg-blue text-cream ring-blue" : "bg-paper text-ink ring-line"),
		children: label
	});
}
var emailOk = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
function MedicalVolunteerForm() {
	const { tx } = useTx();
	const roles = [
		{
			id: "Physician",
			label: {
				en: "Physician",
				es: "Médico"
			}
		},
		{
			id: "Nurse practitioner",
			label: {
				en: "Nurse practitioner",
				es: "Enfermera practicante"
			}
		},
		{
			id: "Physician assistant",
			label: {
				en: "Physician assistant",
				es: "Asistente médico"
			}
		},
		{
			id: "Pharmacist",
			label: {
				en: "Pharmacist",
				es: "Farmacéutico"
			}
		},
		{
			id: "Nurse",
			label: {
				en: "Nurse",
				es: "Enfermería"
			}
		},
		{
			id: "Other licensed role",
			label: {
				en: "Other licensed role",
				es: "Otro rol con licencia"
			}
		}
	];
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("");
	const [license, setLicense] = (0, import_react.useState)("");
	const [licenseState, setLicenseState] = (0, import_react.useState)("");
	const [languages, setLanguages] = (0, import_react.useState)("");
	const [availability, setAvailability] = (0, import_react.useState)("");
	const [website, setWebsite] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [href, setHref] = (0, import_react.useState)("");
	function onSubmit(event) {
		event.preventDefault();
		if (!name.trim() || !emailOk(email) || !phone.trim() || !role || !license.trim() || !licenseState.trim()) {
			setError(tx({
				en: "Name, email, phone, role, license type, and license state are required.",
				es: "El nombre, correo, teléfono, rol, tipo de licencia y estado de la licencia son necesarios."
			}));
			return;
		}
		setError("");
		if (website.trim()) {
			setHref("blocked");
			return;
		}
		const body = [
			"MEDICAL volunteer interest — Canby Community Clinic",
			"Credential information only. No patient information.",
			"",
			`Name: ${name.trim()}`,
			`Email: ${email.trim()}`,
			`Phone: ${phone.trim()}`,
			`Role: ${role}`,
			`License type: ${license.trim()}`,
			`License state: ${licenseState.trim()}`,
			`Languages: ${languages.trim() || "(not given)"}`,
			`Availability: ${availability.trim() || "(not given)"}`,
			"",
			"Interest is not a placement. Licensure will be verified by the clinic."
		].join("\n");
		const next = `mailto:${clinic.emailOffice}?subject=${encodeURIComponent("Medical volunteer interest")}&body=${encodeURIComponent(body)}`;
		setHref(next);
		window.location.href = next;
	}
	if (href && href !== "blocked") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailReady, {
		href,
		title: tx({
			en: "Email the office",
			es: "Escriba a la oficina"
		}),
		body: tx({
			en: `Your email app should open a message to ${clinic.emailOffice}. A licensed role still needs credential review. This is not a placement.`,
			es: `Su correo debería abrir un mensaje a ${clinic.emailOffice}. Un rol con licencia aún requiere revisión de credenciales. Esto no es una colocación.`
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "grid gap-5",
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: tx({
					en: "Full name",
					es: "Nombre completo"
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					autoComplete: "name",
					value: name,
					onChange: (event) => setName(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: tx({
						en: "Email",
						es: "Correo"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "email",
						autoComplete: "email",
						value: email,
						onChange: (event) => setEmail(event.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: tx({
						en: "Phone",
						es: "Teléfono"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "tel",
						autoComplete: "tel",
						value: phone,
						onChange: (event) => setPhone(event.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "text-sm font-medium text-ink",
				children: tx({
					en: "Licensed role",
					es: "Rol con licencia"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-2 sm:grid-cols-2",
				children: roles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					pressed: role === item.id,
					label: tx(item.label),
					onClick: () => setRole(item.id)
				}, item.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: tx({
						en: "License type",
						es: "Tipo de licencia"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: license,
						placeholder: tx({
							en: "MD, DO, NP, PA, RN, RPh…",
							es: "MD, DO, NP, PA, RN, RPh…"
						}),
						onChange: (event) => setLicense(event.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: tx({
						en: "License state",
						es: "Estado de la licencia"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: licenseState,
						placeholder: "CA",
						onChange: (event) => setLicenseState(event.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: tx({
					en: "Languages",
					es: "Idiomas"
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: languages,
					onChange: (event) => setLanguages(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: tx({
					en: "When you can be here",
					es: "Cuándo puede estar aquí"
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: cn(inputClass, "min-h-24 py-3"),
					maxLength: 280,
					value: availability,
					onChange: (event) => setAvailability(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Honeypot, {
				value: website,
				onChange: setWebsite
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "inline-flex min-h-12 items-center justify-center rounded-lg bg-blue px-5 font-medium text-cream",
				children: tx({
					en: "Email medical volunteer interest",
					es: "Enviar interés clínico"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-relaxed text-muted",
				children: tx({
					en: `Opens an email to ${clinic.emailOffice}. Do not include patient names or medical records. The clinic verifies licensure before anyone sees patients.`,
					es: `Abre un correo a ${clinic.emailOffice}. No incluya nombres de pacientes ni expedientes. La clínica verifica la licencia antes de que alguien atienda pacientes.`
				})
			})
		]
	});
}
function CommunityVolunteerForm() {
	const { tx } = useTx();
	const roles = [
		{
			id: "Registration",
			label: {
				en: "Registration",
				es: "Registro"
			}
		},
		{
			id: "Phones and scheduling",
			label: {
				en: "Phones and scheduling",
				es: "Teléfonos y citas"
			}
		},
		{
			id: "Interpretation",
			label: {
				en: "Interpretation",
				es: "Interpretación"
			}
		},
		{
			id: "Outreach",
			label: {
				en: "Outreach",
				es: "Alcance comunitario"
			}
		},
		{
			id: "Administration",
			label: {
				en: "Administration",
				es: "Administración"
			}
		},
		{
			id: "Another non-clinical role",
			label: {
				en: "Another non-clinical role",
				es: "Otro rol no clínico"
			}
		}
	];
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("");
	const [languages, setLanguages] = (0, import_react.useState)("");
	const [availability, setAvailability] = (0, import_react.useState)("");
	const [website, setWebsite] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [href, setHref] = (0, import_react.useState)("");
	function onSubmit(event) {
		event.preventDefault();
		if (!name.trim() || !emailOk(email) || !phone.trim() || !role) {
			setError(tx({
				en: "Name, email, phone, and role are required.",
				es: "El nombre, correo, teléfono y rol son necesarios."
			}));
			return;
		}
		setError("");
		if (website.trim()) {
			setHref("blocked");
			return;
		}
		const body = [
			"NON-MEDICAL volunteer interest — Canby Community Clinic",
			"",
			`Name: ${name.trim()}`,
			`Email: ${email.trim()}`,
			`Phone: ${phone.trim()}`,
			`Role: ${role}`,
			`Languages: ${languages.trim() || "(not given)"}`,
			`Availability: ${availability.trim() || "(not given)"}`,
			"",
			"Interest is not a placement. Do not include patient information."
		].join("\n");
		const next = `mailto:${clinic.emailOffice}?subject=${encodeURIComponent("Non-medical volunteer interest")}&body=${encodeURIComponent(body)}`;
		setHref(next);
		window.location.href = next;
	}
	if (href && href !== "blocked") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailReady, {
		href,
		title: tx({
			en: "Email the office",
			es: "Escriba a la oficina"
		}),
		body: tx({
			en: `Your email app should open a message to ${clinic.emailOffice}. The clinic will say whether this role is needed right now.`,
			es: `Su correo debería abrir un mensaje a ${clinic.emailOffice}. La clínica dirá si este rol hace falta ahora.`
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "grid gap-5",
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: tx({
					en: "Full name",
					es: "Nombre completo"
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					autoComplete: "name",
					value: name,
					onChange: (event) => setName(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: tx({
						en: "Email",
						es: "Correo"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "email",
						autoComplete: "email",
						value: email,
						onChange: (event) => setEmail(event.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: tx({
						en: "Phone",
						es: "Teléfono"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "tel",
						autoComplete: "tel",
						value: phone,
						onChange: (event) => setPhone(event.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "text-sm font-medium text-ink",
				children: tx({
					en: "How you want to help",
					es: "Cómo quiere ayudar"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-2 sm:grid-cols-2",
				children: roles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					pressed: role === item.id,
					label: tx(item.label),
					onClick: () => setRole(item.id)
				}, item.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: tx({
					en: "Languages",
					es: "Idiomas"
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: languages,
					onChange: (event) => setLanguages(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: tx({
					en: "When you are usually free",
					es: "Cuándo suele estar disponible"
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: cn(inputClass, "min-h-24 py-3"),
					maxLength: 280,
					value: availability,
					onChange: (event) => setAvailability(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Honeypot, {
				value: website,
				onChange: setWebsite
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "inline-flex min-h-12 items-center justify-center rounded-lg bg-green px-5 font-medium text-cream",
				children: tx({
					en: "Email non-medical interest",
					es: "Enviar interés no clínico"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-relaxed text-muted",
				children: tx({
					en: `Opens an email to ${clinic.emailOffice}. Do not include anyone else’s medical information.`,
					es: `Abre un correo a ${clinic.emailOffice}. No incluya información médica de otra persona.`
				})
			})
		]
	});
}
function DonateForm() {
	const { tx } = useTx();
	const amounts = [
		"50",
		"100",
		"250",
		"500",
		"other"
	];
	const funds = [
		{
			id: "Wherever it is needed",
			label: {
				en: "Wherever it is needed",
				es: "Donde haga falta"
			}
		},
		{
			id: "Medical supplies",
			label: {
				en: "Medical supplies",
				es: "Insumos médicos"
			}
		},
		{
			id: "Medications",
			label: {
				en: "Medications",
				es: "Medicamentos"
			}
		},
		{
			id: "Health education",
			label: {
				en: "Health education",
				es: "Educación en salud"
			}
		},
		{
			id: "Operations",
			label: {
				en: "Keeping the clinic open",
				es: "Mantener la clínica abierta"
			}
		}
	];
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [other, setOther] = (0, import_react.useState)("");
	const [fund, setFund] = (0, import_react.useState)("Wherever it is needed");
	const [note, setNote] = (0, import_react.useState)("");
	const [ack, setAck] = (0, import_react.useState)(false);
	const [website, setWebsite] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [href, setHref] = (0, import_react.useState)("");
	function onSubmit(event) {
		event.preventDefault();
		const gift = amount === "other" ? other.trim() : amount ? `$${amount}` : "";
		if (!name.trim() || !emailOk(email) || !gift || !ack) {
			setError(tx({
				en: "Name, email, an amount, and the confirmation are required.",
				es: "El nombre, el correo, un monto y la confirmación son necesarios."
			}));
			return;
		}
		setError("");
		if (website.trim()) {
			setHref("blocked");
			return;
		}
		const body = [
			"Donation interest — Canby Community Clinic",
			"This message does not charge a card and is not a completed gift.",
			"",
			`Name: ${name.trim()}`,
			`Email: ${email.trim()}`,
			`Phone: ${phone.trim() || "(not given)"}`,
			`Intended amount: ${gift}`,
			`Hope to support: ${fund}`,
			`Note: ${note.trim() || "(none)"}`,
			"",
			"Please confirm the legal payee, EIN 87-1610266, and how to complete the gift."
		].join("\n");
		const next = `mailto:${clinic.emailOffice}?subject=${encodeURIComponent("Donation interest")}&body=${encodeURIComponent(body)}`;
		setHref(next);
		window.location.href = next;
	}
	if (href && href !== "blocked") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailReady, {
		href,
		title: tx({
			en: "The office has to confirm the gift.",
			es: "La oficina debe confirmar el donativo."
		}),
		body: tx({
			en: `Nothing was charged. Your email app should open a note to ${clinic.emailOffice}. Wait for the legal payee before you mail a check.`,
			es: `No se cobró nada. Su correo debería abrir una nota a ${clinic.emailOffice}. Espere el beneficiario legal antes de enviar un cheque.`
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "grid gap-5",
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: tx({
					en: "Name",
					es: "Nombre"
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					autoComplete: "name",
					value: name,
					onChange: (event) => setName(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: tx({
						en: "Email",
						es: "Correo"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "email",
						autoComplete: "email",
						value: email,
						onChange: (event) => setEmail(event.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: tx({
						en: "Phone, optional",
						es: "Teléfono, opcional"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "tel",
						autoComplete: "tel",
						value: phone,
						onChange: (event) => setPhone(event.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "text-sm font-medium text-ink",
					children: tx({
						en: "Amount you have in mind",
						es: "Monto que tiene en mente"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-3 gap-2 sm:grid-cols-5",
					children: amounts.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						pressed: amount === item,
						label: item === "other" ? tx({
							en: "Other",
							es: "Otro"
						}) : `$${item}`,
						onClick: () => setAmount(item)
					}, item))
				}),
				amount === "other" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: cn(inputClass, "mt-3"),
					inputMode: "decimal",
					placeholder: tx({
						en: "Amount",
						es: "Monto"
					}),
					value: other,
					onChange: (event) => setOther(event.target.value)
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "text-sm font-medium text-ink",
				children: tx({
					en: "What you hope it supports",
					es: "Qué espera que apoye"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-2",
				children: funds.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					pressed: fund === item.id,
					label: tx(item.label),
					onClick: () => setFund(item.id)
				}, item.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: tx({
					en: "Note, optional",
					es: "Nota, opcional"
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: cn(inputClass, "min-h-24 py-3"),
					maxLength: 280,
					value: note,
					onChange: (event) => setNote(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-start gap-3 text-sm leading-relaxed text-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "mt-1 size-5 accent-blue",
					checked: ack,
					onChange: (event) => setAck(event.target.checked)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tx({
					en: "I understand this form does not charge a card or complete a donation. The office will confirm the legal name and payee before I send anything.",
					es: "Entiendo que este formulario no cobra una tarjeta ni completa un donativo. La oficina confirmará el nombre legal y el beneficiario antes de que yo envíe algo."
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Honeypot, {
				value: website,
				onChange: setWebsite
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "inline-flex min-h-12 items-center justify-center rounded-lg bg-blue px-5 font-medium text-cream",
				children: tx({
					en: "Email the office about a gift",
					es: "Escribir a la oficina sobre un donativo"
				})
			})
		]
	});
}
function Honeypot({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "sr-only",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Website", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			tabIndex: -1,
			autoComplete: "off",
			value,
			onChange: (event) => onChange(event.target.value)
		})] })
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-DgWbPDCs.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var nav = [
	{
		to: "/services",
		label: {
			en: "Services",
			es: "Servicios"
		}
	},
	{
		to: "/visit",
		label: {
			en: "Your visit",
			es: "Su visita"
		}
	},
	{
		to: "/volunteer",
		label: {
			en: "Volunteer",
			es: "Voluntariado"
		}
	},
	{
		to: "/give",
		label: {
			en: "Donate",
			es: "Donar"
		}
	}
];
var more = [
	{
		to: "/appointments",
		label: {
			en: "Appointments",
			es: "Citas"
		}
	},
	{
		to: "/volunteer",
		label: {
			en: "Volunteer",
			es: "Voluntariado"
		}
	},
	{
		to: "/give",
		label: {
			en: "Donate",
			es: "Donar"
		}
	},
	{
		to: "/privacy",
		label: {
			en: "Privacy",
			es: "Privacidad"
		}
	},
	{
		to: "/terms",
		label: {
			en: "Terms",
			es: "Términos"
		}
	}
];
function LangToggle({ compact = false }) {
	const { lang, setLang, tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("inline-flex rounded-lg bg-paper p-1 ring-1 ring-line", compact && "bg-cream"),
		role: "group",
		"aria-label": tx({
			en: "Language",
			es: "Idioma"
		}),
		children: ["en", "es"].map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-pressed": lang === code,
			onClick: () => setLang(code),
			className: cn("min-h-10 min-w-11 rounded-md px-2 text-sm font-medium", lang === code ? "bg-blue text-cream" : "text-muted hover:text-ink"),
			children: code === "en" ? "EN" : "ES"
		}, code))
	});
}
function SiteFrame({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-paper pb-24 text-ink md:pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:bg-cream focus:px-4 focus:py-3",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmergencyBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "main",
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileDock, {})
		]
	});
}
function EmergencyBar() {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "bg-ink text-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Container, {
			className: "py-2 text-center text-xs leading-relaxed md:text-sm",
			children: tx({
				en: "Medical emergency? Call 911. This is not an emergency department, and this website is not monitored for emergencies.",
				es: "¿Emergencia médica? Llame al 911. Esto no es una sala de emergencias y este sitio no se vigila para emergencias."
			})
		})
	});
}
function Header() {
	const { tx } = useTx();
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		document.body.style.overflow = "hidden";
		window.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = "";
			window.removeEventListener("keydown", onKey);
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-line bg-cream/95 backdrop-blur",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "flex min-h-16 items-center gap-4 py-3 md:min-h-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "shrink-0",
					"aria-label": clinic.name,
					onClick: () => setOpen(false),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/media/logo.png",
						alt: clinic.name,
						className: "h-11 w-auto max-w-48 object-contain object-left md:h-14 md:max-w-64"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "ml-auto hidden items-center gap-6 lg:flex",
					"aria-label": "Primary",
					children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: "text-sm font-medium text-muted hover:text-ink",
						activeProps: { className: "text-sm font-medium text-blue" },
						children: tx(item.label)
					}, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto hidden items-center gap-3 lg:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangToggle, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `tel:${clinic.phoneTel}`,
							className: "text-sm font-medium text-blue tabular-nums hover:text-blue-deep",
							children: clinic.phoneDisplay
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestButton, { className: "min-h-11 px-4 text-sm" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center gap-2 lg:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangToggle, { compact: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex size-11 items-center justify-center rounded-lg ring-1 ring-line",
						"aria-expanded": open,
						"aria-label": tx({
							en: open ? "Close menu" : "Open menu",
							es: open ? "Cerrar menú" : "Abrir menú"
						}),
						onClick: () => setOpen((value) => !value),
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					})]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-line bg-cream lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "flex flex-col gap-1 py-4",
				children: [
					nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						onClick: () => setOpen(false),
						className: "min-h-12 rounded-lg px-2 py-3 text-lg text-ink",
						activeProps: { className: "min-h-12 rounded-lg bg-blue-soft px-2 py-3 text-lg text-blue" },
						children: tx(item.label)
					}, item.to)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/about",
						onClick: () => setOpen(false),
						className: "min-h-12 rounded-lg px-2 py-3 text-lg text-ink",
						children: tx({
							en: "About",
							es: "Nosotros"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/resources",
						onClick: () => setOpen(false),
						className: "min-h-12 rounded-lg px-2 py-3 text-lg text-ink",
						children: tx({
							en: "Resources",
							es: "Recursos"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/appointments",
						onClick: () => setOpen(false),
						className: "min-h-12 rounded-lg px-2 py-3 text-lg text-ink",
						children: tx({
							en: "Appointments",
							es: "Citas"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallButton, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestButton, {})]
					})
				]
			})
		}) : null]
	});
}
function Footer() {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-line bg-cream",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid gap-10 py-14 md:grid-cols-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/media/logo.png",
							alt: "",
							className: "h-14 w-auto"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-xs text-sm leading-relaxed text-muted",
							children: tx({
								en: `Formerly ${clinic.former}. A community clinic in Reseda.`,
								es: `Antes ${clinic.former}. Una clínica comunitaria en Reseda.`
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-xs text-xs leading-relaxed text-muted",
							children: tx({
								en: "Photographs on this website are illustrative. They are not pictures of our building, staff, or patients.",
								es: "Las fotografías de este sitio son ilustrativas. No son imágenes de nuestro edificio, personal ni pacientes."
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium text-ink",
							children: tx({
								en: "Visit",
								es: "Visítenos"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("address", {
							className: "mt-3 text-sm leading-relaxed text-muted not-italic",
							children: [
								clinic.street,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								clinic.city
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted",
							children: [
								tx({
									en: "Monday–Friday, 9 AM–5 PM",
									es: "Lunes a viernes, 9 AM–5 PM"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								tx({
									en: "Saturday and Sunday, closed",
									es: "Sábado y domingo, cerrado"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: clinic.mapsUrl,
							className: "mt-3 inline-flex min-h-11 items-center text-sm font-medium text-blue",
							target: "_blank",
							rel: "noreferrer",
							children: tx({
								en: "Open in Maps",
								es: "Abrir en Maps"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium text-ink",
							children: tx({
								en: "Which contact to use",
								es: "Qué contacto usar"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: tx({
								en: "Patients and appointments",
								es: "Pacientes y citas"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "text-sm font-medium text-blue",
							href: `mailto:${clinic.emailPatients}`,
							children: clinic.emailPatients
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "font-medium text-blue tabular-nums",
								href: `tel:${clinic.phoneTel}`,
								children: clinic.phoneDisplay
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm leading-relaxed text-muted",
							children: tx({
								en: "Office, volunteers, and gifts",
								es: "Oficina, voluntarios y donaciones"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "text-sm font-medium text-blue",
							href: `mailto:${clinic.emailOffice}`,
							children: clinic.emailOffice
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs leading-relaxed text-danger",
							children: tx({
								en: "Do not email symptoms, diagnoses, test results, insurance ID numbers, Social Security numbers, or medical records. Ordinary email is not a secure medical channel.",
								es: "No envíe por correo síntomas, diagnósticos, resultados, números de seguro, números de Seguro Social ni expedientes. El correo ordinario no es un canal médico seguro."
							})
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "flex flex-col gap-4 py-5 md:flex-row md:items-center md:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" ",
						clinic.name
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-wrap gap-x-4 gap-y-2",
					"aria-label": "Footer",
					children: more.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: "text-xs font-medium text-muted hover:text-ink",
						children: tx(item.label)
					}, item.to))
				})]
			})
		})]
	});
}
function MobileDock() {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-x-0 bottom-0 z-30 border-t border-line bg-cream/95 p-3 backdrop-blur md:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2 pr-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallButton, { className: "px-2 text-sm" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/appointments",
				className: "inline-flex min-h-12 items-center justify-center rounded-lg bg-blue px-2 text-sm font-medium text-cream",
				children: tx({
					en: "Request",
					es: "Solicitar"
				})
			})]
		})
	});
}
var styles_default = "/assets/styles-B1yUrt2b.css";
var structuredData = {
	"@context": "https://schema.org",
	"@type": "MedicalClinic",
	name: clinic.name,
	alternateName: clinic.former,
	telephone: clinic.phoneTel,
	email: clinic.emailPatients,
	address: {
		"@type": "PostalAddress",
		streetAddress: clinic.street,
		addressLocality: "Reseda",
		addressRegion: "CA",
		postalCode: "91335",
		addressCountry: "US"
	},
	openingHoursSpecification: [{
		"@type": "OpeningHoursSpecification",
		dayOfWeek: [
			"Monday",
			"Tuesday",
			"Wednesday",
			"Thursday",
			"Friday"
		],
		opens: "09:00",
		closes: "17:00"
	}],
	identifier: clinic.npi
};
var Route$13 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Canby Community Clinic" },
			{
				name: "description",
				content: "Canby Community Clinic in Reseda, formerly Pura Vida Community Clinic. Weekday primary care built around listening. Call (818) 674-4414 or request an appointment."
			},
			{
				name: "theme-color",
				content: "#0d4f98"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,520;9..144,620&family=Outfit:wght@300;400;500;600&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify(structuredData)
		}]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(I18nProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$11 = () => import("./routes-BcLsFNwX.mjs");
var Route$12 = createFileRoute("/")({
	head: () => ({ meta: [{ title: "Canby Community Clinic | Reseda" }, {
		name: "description",
		content: "Canby Community Clinic, formerly Pura Vida, in Reseda. A weekday visit built around listening, a clear explanation, and a plan for what happens next. Call (818) 674-4414."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("../_-wwqQCR03.mjs");
var Route$11 = createFileRoute("/$")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./about-DrtiAmKC.mjs");
var Route$10 = createFileRoute("/about")({
	head: () => ({ meta: [{ title: "About | Canby Community Clinic" }, {
		name: "description",
		content: "Canby Community Clinic, formerly Pura Vida Community Clinic, is a community clinic in Reseda. Public registration, hours, and how care is delivered — without unverified claims."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./appointments-hvpLqyHy.mjs");
var Route$9 = createFileRoute("/appointments")({
	head: () => ({ meta: [{ title: "Request an appointment | Canby Community Clinic" }, {
		name: "description",
		content: "Call (818) 674-4414 or send only the contact details needed to schedule a visit at Canby Community Clinic in Reseda. Do not include medical information."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./contact-CiEjfz7v.mjs");
var Route$8 = createFileRoute("/contact")({
	head: () => ({ meta: [{ title: "Contact | Canby Community Clinic" }, {
		name: "description",
		content: "Contact Canby Community Clinic in Reseda. Patients: Info@canbycc.org or (818) 674-4414. Office: office@canbycc.org. Do not email medical information."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./donate-DD7y1sV7.mjs");
var Route$7 = createFileRoute("/donate")({
	head: () => ({ meta: [{ title: "Donate | Canby Community Clinic" }, {
		name: "description",
		content: "Donate to Canby Community Clinic. Tell the office an amount and what you hope to support. This website does not charge a card."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var Route$6 = createFileRoute("/give")({
	head: () => ({ meta: [{ title: "Donate | Canby Community Clinic" }, {
		name: "description",
		content: "Donate to Canby Community Clinic. Tell the office an amount and what you hope to support. This website does not charge a card."
	}] }),
	component: GivePage
});
function GivePage() {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		kicker: tx({
			en: "Donate",
			es: "Donar"
		}),
		title: tx({
			en: "A gift with a name, not a checkout button.",
			es: "Un donativo con nombre, no un botón de pago."
		}),
		lede: tx({
			en: "Supplies, medications, education, and the cost of staying open. Say what you have in mind. The office confirms the legal payee before any money moves. Nothing on this page charges a card.",
			es: "Insumos, medicamentos, educación y el costo de seguir abiertos. Diga lo que tiene en mente. La oficina confirma el beneficiario legal antes de que se mueva dinero. Nada en esta página cobra una tarjeta."
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
		className: "grid gap-10 py-12 md:grid-cols-12 md:py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "md:col-span-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: tx({
					en: `Canby Community Clinic Inc. is a 501(c)(3), EIN ${clinic.ein}. Confirm the legal name and current tax status with the office before you claim a deduction.`,
					es: `Canby Community Clinic Inc. es una 501(c)(3), EIN ${clinic.ein}. Confirme el nombre legal y la situación fiscal con la oficina antes de deducir un donativo.`
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 border border-line bg-cream p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: tx({
							en: "After the office replies",
							es: "Después de que responda la oficina"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: tx({
							en: "Checks, once the payee is confirmed, can be mailed to:",
							es: "Los cheques, una vez confirmado el beneficiario, pueden enviarse a:"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-medium",
						children: [
							clinic.name,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							clinic.street,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							clinic.city
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "mt-4 inline-flex min-h-11 items-center font-medium text-blue",
						href: `mailto:${clinic.emailOffice}`,
						children: clinic.emailOffice
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-lg border border-line bg-cream p-5 md:col-span-7 md:p-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonateForm, {})
		})]
	})] });
}
var $$splitComponentImporter$5 = () => import("./privacy-Bj3JhRUK.mjs");
var Route$5 = createFileRoute("/privacy")({
	head: () => ({ meta: [{ title: "Privacy | Canby Community Clinic" }, {
		name: "description",
		content: "Website privacy notice for Canby Community Clinic. This page is not the clinic’s Notice of Privacy Practices. Do not send medical information by ordinary email."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./resources-CF6GNsGj.mjs");
var Route$4 = createFileRoute("/resources")({
	head: () => ({ meta: [{ title: "Resources | Canby Community Clinic" }, {
		name: "description",
		content: "Questions patients ask Canby Community Clinic, what to prepare, and official public resources for coverage, emergencies, and preventive care."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./services-6mOUIR-R.mjs");
var Route$3 = createFileRoute("/services")({
	head: () => ({ meta: [{ title: "Services | Canby Community Clinic" }, {
		name: "description",
		content: "Primary care, preventive checks, lab coordination, medication help, health education, and community resource navigation at Canby Community Clinic in Reseda. Call to confirm availability."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./terms-DjdlOWRO.mjs");
var Route$2 = createFileRoute("/terms")({
	head: () => ({ meta: [{ title: "Terms | Canby Community Clinic" }, {
		name: "description",
		content: "Website terms for Canby Community Clinic. The site is not medical advice, not an emergency service, and not a confirmed appointment."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./visit-ByFYtHI3.mjs");
var Route$1 = createFileRoute("/visit")({
	head: () => ({ meta: [{ title: "Your visit | Canby Community Clinic" }, {
		name: "description",
		content: "What a visit at Canby Community Clinic is like, what to bring, and how new patients get started. Call (818) 674-4414. Do not send medical details by email."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./volunteer-BMRRImRm.mjs");
var Route = createFileRoute("/volunteer")({
	head: () => ({ meta: [{ title: "Volunteer | Canby Community Clinic" }, {
		name: "description",
		content: "Two volunteer signups for Canby Community Clinic: licensed medical roles, and non-medical roles such as registration, phones, interpretation, and outreach."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$12.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$13
	}),
	SplatRoute: Route$11.update({
		id: "/$",
		path: "/$",
		getParentRoute: () => Route$13
	}),
	AboutRoute: Route$10.update({
		id: "/about",
		path: "/about",
		getParentRoute: () => Route$13
	}),
	AppointmentsRoute: Route$9.update({
		id: "/appointments",
		path: "/appointments",
		getParentRoute: () => Route$13
	}),
	ContactRoute: Route$8.update({
		id: "/contact",
		path: "/contact",
		getParentRoute: () => Route$13
	}),
	DonateRoute: Route$7.update({
		id: "/donate",
		path: "/donate",
		getParentRoute: () => Route$13
	}),
	GiveRoute: Route$6.update({
		id: "/give",
		path: "/give",
		getParentRoute: () => Route$13
	}),
	PrivacyRoute: Route$5.update({
		id: "/privacy",
		path: "/privacy",
		getParentRoute: () => Route$13
	}),
	ResourcesRoute: Route$4.update({
		id: "/resources",
		path: "/resources",
		getParentRoute: () => Route$13
	}),
	ServicesRoute: Route$3.update({
		id: "/services",
		path: "/services",
		getParentRoute: () => Route$13
	}),
	TermsRoute: Route$2.update({
		id: "/terms",
		path: "/terms",
		getParentRoute: () => Route$13
	}),
	VisitRoute: Route$1.update({
		id: "/visit",
		path: "/visit",
		getParentRoute: () => Route$13
	}),
	VolunteerRoute: Route.update({
		id: "/volunteer",
		path: "/volunteer",
		getParentRoute: () => Route$13
	})
};
var routeTree = Route$13._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { MedicalVolunteerForm as a, CommunityVolunteerForm as i, GivePage as n, AppointmentForm as r, router_exports as t };
