import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as PageIntro, f as clinic, l as Photo, m as useTx, n as Container, r as FinalCta } from "./ui-pby2H8c5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/visit-ByFYtHI3.js
var import_jsx_runtime = require_jsx_runtime();
var moments = [
	{
		n: "01",
		title: {
			en: "You reach us",
			es: "Usted nos contacta"
		},
		body: {
			en: "A phone call, or a short request with only the details needed to call you back. No history, no symptoms, no insurance number through the website.",
			es: "Una llamada, o una solicitud breve solo con lo necesario para devolverle la llamada. Sin historia, sin síntomas y sin número de seguro por el sitio."
		}
	},
	{
		n: "02",
		title: {
			en: "We confirm",
			es: "Confirmamos"
		},
		body: {
			en: "You hear whether the service is available, what eligibility and cost look like, and which documents to bring. Until then, you do not have an appointment.",
			es: "Usted escucha si el servicio está disponible, cómo son la elegibilidad y el costo, y qué documentos traer. Hasta entonces, no tiene una cita."
		}
	},
	{
		n: "03",
		title: {
			en: "You are heard",
			es: "Lo escuchan"
		},
		body: {
			en: "The visit stays with your concern, your medicines, and the questions you wrote down. An exam and measurements are done when they change the plan.",
			es: "La visita se queda con su motivo, sus medicamentos y las preguntas que anotó. El examen y las medidas se hacen cuando cambian el plan."
		}
	},
	{
		n: "04",
		title: {
			en: "You leave knowing",
			es: "Se va sabiendo"
		},
		body: {
			en: "Treatment, a test, a follow-up, a referral, or a community resource — which one, and how to take it. If the answer is “not here,” that is said out loud.",
			es: "Tratamiento, una prueba, un seguimiento, una referencia o un recurso comunitario: cuál, y cómo seguirlo. Si la respuesta es “aquí no”, se dice en voz alta."
		}
	}
];
var bring = [
	{
		en: "Photo identification, when you have it",
		es: "Identificación con foto, si la tiene"
	},
	{
		en: "A current list of prescriptions, over-the-counter medicines, vitamins, and supplements",
		es: "Una lista actual de recetas, medicamentos sin receta, vitaminas y suplementos"
	},
	{
		en: "The bottles themselves, if a written list is hard to make",
		es: "Los frascos, si es difícil hacer una lista escrita"
	},
	{
		en: "Test results, discharge papers, or specialist notes you already have on paper",
		es: "Resultados, hojas de alta o notas de especialistas que ya tenga en papel"
	},
	{
		en: "Insurance information, if you have coverage",
		es: "Información del seguro, si tiene cobertura"
	},
	{
		en: "Your pharmacy’s name and phone number",
		es: "El nombre y teléfono de su farmacia"
	},
	{
		en: "Two or three questions you do not want to forget",
		es: "Dos o tres preguntas que no quiere olvidar"
	}
];
function VisitPage() {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			kicker: tx({
				en: "Your visit",
				es: "Su visita"
			}),
			title: tx({
				en: "Enough time to understand. A plan before you leave.",
				es: "Tiempo suficiente para entender. Un plan antes de irse."
			}),
			lede: tx({
				en: "New and returning patients follow the same path: reach us, wait for confirmation, arrive prepared, and leave knowing the next step. This page is the whole path.",
				es: "Pacientes nuevos y conocidos siguen el mismo camino: contactarnos, esperar la confirmación, llegar preparados y salir sabiendo el siguiente paso. Esta página es todo el camino."
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid items-center gap-10 py-14 md:grid-cols-2 md:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
				src: "/media/family.jpg",
				alt: tx({
					en: "Two family members waiting together. Illustrative photograph.",
					es: "Dos familiares esperan juntos. Fotografía ilustrativa."
				}),
				className: "aspect-portrait w-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-4xl leading-tight",
					children: tx({
						en: "Bring someone if that helps you be heard.",
						es: "Traiga a alguien si eso le ayuda a ser escuchado."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 leading-relaxed text-muted",
					children: tx({
						en: "Information is available in English and Spanish. Tell us when you schedule if you need an interpreter or want a family member in the room. Say so early, so we can tell you what we can arrange.",
						es: "La información está disponible en inglés y en español. Díganos al programar si necesita un intérprete o quiere a un familiar en el cuarto. Dígalo pronto, para decirle qué podemos organizar."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 leading-relaxed text-muted",
					children: tx({
						en: "Cost, insurance status, language, transportation, and the simple difficulty of finding an appointment keep people out of basic care. The clinic exists to lower those barriers — not to pretend they are gone. Ask about cost and eligibility before you come.",
						es: "El costo, el seguro, el idioma, el transporte y la simple dificultad de encontrar una cita alejan a la gente de la atención básica. La clínica existe para bajar esas barreras, no para fingir que desaparecieron. Pregunte por el costo y la elegibilidad antes de venir."
					})
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "py-14 md:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-4xl",
					children: tx({
						en: "Four moments of one visit",
						es: "Cuatro momentos de una visita"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-8 md:grid-cols-2",
					children: moments.map((moment) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "border-t border-line pt-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-serif text-3xl text-green",
								children: moment.n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 font-serif text-2xl",
								children: tx(moment.title)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 leading-relaxed text-muted",
								children: tx(moment.body)
							})
						]
					}, moment.n))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid gap-12 py-14 md:grid-cols-2 md:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-3xl",
					children: tx({
						en: "What a visit may include",
						es: "Qué puede incluir una visita"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 space-y-3 text-sm leading-relaxed",
					children: [
						{
							en: "Your main concern, health history, and medications",
							es: "Su motivo principal, historia de salud y medicamentos"
						},
						{
							en: "Measurements when they are useful",
							es: "Medidas cuando son útiles"
						},
						{
							en: "A focused physical examination",
							es: "Un examen físico enfocado"
						},
						{
							en: "Preventive recommendations based on age, history, and risk",
							es: "Recomendaciones preventivas según edad, historia y riesgo"
						},
						{
							en: "A named plan: treatment, testing, follow-up, or referral",
							es: "Un plan con nombre: tratamiento, pruebas, seguimiento o referencia"
						}
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "border-l-2 border-blue pl-3",
						children: tx(item)
					}, item.en))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-sm leading-relaxed text-muted",
					children: tx({
						en: "Primary care can help an adult who wants a general checkup, follow-up for a stable condition, or a non-emergency place to start. The clinic decides whether a concern can be addressed safely here.",
						es: "La atención primaria puede ayudar a un adulto que quiere un chequeo general, seguimiento de una condición estable o un lugar no urgente por dónde empezar. La clínica decide si un problema se puede atender aquí con seguridad."
					})
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-3xl",
					children: tx({
						en: "What to bring",
						es: "Qué traer"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 space-y-3",
					children: bring.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3 text-sm leading-relaxed",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 size-2 shrink-0 rounded-full bg-green",
							"aria-hidden": true
						}), tx(item)]
					}, item.en))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-sm leading-relaxed text-danger",
					children: tx({
						en: "Do not email medical records, Social Security numbers, insurance member numbers, diagnoses, or test results to a general inbox. Ask the clinic for an approved secure method when records are needed.",
						es: "No envíe expedientes, números de Seguro Social, números de seguro, diagnósticos ni resultados a un correo general. Pida a la clínica un método seguro aprobado cuando hagan falta documentos."
					})
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-line bg-ink text-cream",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "grid gap-6 py-12 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: tx({
							en: "Cost and eligibility",
							es: "Costo y elegibilidad"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-cream/80",
						children: tx({
							en: "Costs, insurance requirements, eligibility, and availability change. Do not assume every service is free, and do not assume your plan is accepted. Call first.",
							es: "Los costos, los requisitos del seguro, la elegibilidad y la disponibilidad cambian. No suponga que todo servicio es gratis ni que aceptan su plan. Llame primero."
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: tx({
							en: "Arrive prepared",
							es: "Llegue preparado"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-cream/80",
						children: tx({
							en: "Confirm the suite, the time, and whether you need to fast or do anything else before you come. Allow time for parking and check-in.",
							es: "Confirme la suite, la hora y si debe ayunar o hacer algo más antes de venir. Tome en cuenta el estacionamiento y el registro."
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: tx({
							en: "Not an emergency",
							es: "No es una emergencia"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-cream/80",
						children: tx({
							en: `This website is not watched for emergencies. Call 911 or go to the nearest emergency department. For a weekday visit, call ${clinic.phoneDisplay}.`,
							es: `Este sitio no se vigila para emergencias. Llame al 911 o vaya a la sala de emergencias más cercana. Para una visita entre semana, llame al ${clinic.phoneDisplay}.`
						})
					})] })
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
//#endregion
export { VisitPage as component };
