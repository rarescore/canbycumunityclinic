import { t as AppointmentsPage } from "./appointments-page-BzKRMvR3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/appointments-hvpLqyHy.js
var SplitComponent = AppointmentsPage;
//#endregion
export { SplitComponent as component };
