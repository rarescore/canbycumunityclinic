import { t as AppointmentsPage } from "./appointments-page-BzKRMvR3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-CiEjfz7v.js
var SplitComponent = AppointmentsPage;
//#endregion
export { SplitComponent as component };
