import { i as __toESM } from "../_runtime.mjs";
import { R as require_react, _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Pill, c as HeartPulse, i as Stethoscope, l as Compass, r as TestTube, u as BookOpen } from "../_libs/lucide-react.mjs";
import { d as Reveal, f as clinic, i as HoursTable, l as Photo, m as useTx, n as Container, o as IllustrativeNote, s as Kicker, t as CallButton, u as RequestButton } from "./ui-pby2H8c5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BcLsFNwX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function clamp(value) {
	return Math.min(1, Math.max(0, value));
}
function ScrollHero() {
	const { tx } = useTx();
	const stageRef = (0, import_react.useRef)(null);
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [reduced, setReduced] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const media = window.matchMedia("(prefers-reduced-motion: reduce)");
		const apply = () => setReduced(media.matches);
		apply();
		media.addEventListener("change", apply);
		const onScroll = () => {
			const stage = stageRef.current;
			if (!stage || media.matches) return;
			const total = stage.offsetHeight - window.innerHeight;
			const scrolled = Math.min(Math.max(-stage.getBoundingClientRect().top, 0), Math.max(total, 1));
			setProgress(total > 0 ? scrolled / total : 0);
		};
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		window.addEventListener("resize", onScroll);
		return () => {
			media.removeEventListener("change", apply);
			window.removeEventListener("scroll", onScroll);
			window.removeEventListener("resize", onScroll);
		};
	}, []);
	const p = reduced ? 1 : progress;
	const first = 1 - clamp((p - .18) / .34);
	const second = clamp((p - .42) / .34);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		ref: stageRef,
		className: "hero-stage bg-ink text-cream",
		"aria-label": tx({
			en: "Introduction",
			es: "Introducción"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hero-pin",
			style: { ["--p"]: String(p) },
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hero-photo absolute inset-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/media/listen.jpg",
					alt: tx({
						en: "A clinician sits with a patient and listens. Illustrative photograph.",
						es: "Una persona clínica escucha a una paciente. Fotografía ilustrativa."
					}),
					className: "h-full w-full object-cover",
					width: 1792,
					height: 1008
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-shade absolute inset-0" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "relative z-10 flex h-full flex-col justify-end pb-16 md:pb-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hero-rise text-xs font-medium tracking-widest text-green-soft uppercase",
						style: { animationDelay: "80ms" },
						children: tx({
							en: "Canby Community Clinic · Reseda",
							es: "Canby Community Clinic · Reseda"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mt-3 min-h-24 max-w-4xl md:mt-4 md:min-h-64",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-serif text-4xl leading-none text-cream md:text-7xl",
							style: { opacity: first },
							children: tx({
								en: "Heard clearly.",
								es: "Escuchado con claridad."
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "absolute inset-x-0 top-0 font-serif text-4xl leading-none text-cream md:text-7xl",
							style: { opacity: second },
							"aria-hidden": second < .4,
							children: tx({
								en: "Then a plan you can follow.",
								es: "Después, un plan que puede seguir."
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hero-rise mt-3 max-w-xl text-sm leading-relaxed text-cream/85 md:mt-6 md:text-lg",
						style: { animationDelay: "220ms" },
						children: tx({
							en: "Formerly Pura Vida. A weekday clinic on Canby Avenue — a real conversation about what is happening, and what comes next.",
							es: "Antes Pura Vida. Una clínica de lunes a viernes en Canby Avenue: una conversación real sobre qué pasa y qué sigue."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hero-rise mt-4 flex flex-col gap-2 sm:flex-row md:mt-8 md:gap-3",
						style: { animationDelay: "340ms" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallButton, { variant: "inverse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestButton, { variant: "quiet" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-end justify-between gap-6 md:mt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-cream/80",
							children: [
								clinic.street,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "hidden sm:inline",
									children: [" · ", clinic.city]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-cream/70",
									children: tx({
										en: "Weekdays 9–5 · English and Spanish",
										es: "Lunes a viernes, 9–5 · Inglés y español"
									})
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden items-center gap-3 md:flex",
							"aria-hidden": true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs tracking-widest text-cream/70 uppercase",
								children: tx({
									en: "Scroll",
									es: "Deslice"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "relative block h-14 w-px bg-cream/30",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hero-scroll-line absolute inset-x-0 top-0 h-full w-px bg-green-soft" })
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-px w-full bg-cream/20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-px bg-green-soft",
							style: { width: `${Math.round(p * 100)}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 hidden max-w-md md:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IllustrativeNote, { light: true })
					})
				]
			})]
		})
	});
}
var promises = [
	{
		n: "01",
		title: {
			en: "You are listened to",
			es: "Lo escuchamos"
		},
		body: {
			en: "The visit starts with your story, your medicines, and the question you actually came in with.",
			es: "La visita empieza con su historia, sus medicamentos y la pregunta con la que realmente llegó."
		}
	},
	{
		n: "02",
		title: {
			en: "There is time to talk",
			es: "Hay tiempo para hablar"
		},
		body: {
			en: "The visit is organized so the conversation is not a race to the door. We do not publish a minute count we cannot stand behind.",
			es: "La visita se organiza para que la conversación no sea una carrera hacia la puerta. No publicamos un número de minutos que no podamos sostener."
		}
	},
	{
		n: "03",
		title: {
			en: "You understand it",
			es: "Usted lo entiende"
		},
		body: {
			en: "Findings and choices are explained in ordinary language, in English or Spanish.",
			es: "Los hallazgos y las opciones se explican en lenguaje sencillo, en inglés o en español."
		}
	},
	{
		n: "04",
		title: {
			en: "You leave with a direction",
			es: "Se va con una dirección"
		},
		body: {
			en: "A treatment, a test, a referral, or another resource — named, so you know what happens next.",
			es: "Un tratamiento, una prueba, una referencia u otro recurso, con nombre, para que sepa qué sigue."
		}
	}
];
var services = [
	{
		icon: Stethoscope,
		title: {
			en: "Primary care",
			es: "Atención primaria"
		},
		body: {
			en: "A general visit, follow-up, medication review, and a referral when you need one.",
			es: "Una visita general, seguimiento, revisión de medicamentos y una referencia cuando haga falta."
		}
	},
	{
		icon: HeartPulse,
		title: {
			en: "Preventive checks",
			es: "Revisiones preventivas"
		},
		body: {
			en: "Blood pressure, diabetes risk, and preventive guidance matched to age and history.",
			es: "Presión arterial, riesgo de diabetes y orientación preventiva según la edad y la historia."
		}
	},
	{
		icon: TestTube,
		title: {
			en: "Labs and tests",
			es: "Laboratorios y pruebas"
		},
		body: {
			en: "Help arranging basic tests when they are clinically appropriate. Fees are confirmed first.",
			es: "Ayuda para coordinar pruebas básicas cuando son apropiadas. Las tarifas se confirman antes."
		}
	},
	{
		icon: Pill,
		title: {
			en: "Medication help",
			es: "Ayuda con medicamentos"
		},
		body: {
			en: "Help understanding a prescription or finding certain medicines. Nothing is guaranteed in stock.",
			es: "Ayuda para entender una receta o encontrar ciertos medicamentos. Nada está garantizado en existencia."
		}
	},
	{
		icon: BookOpen,
		title: {
			en: "Health education",
			es: "Educación en salud"
		},
		body: {
			en: "Plain explanations of results, medicines, prevention, and the steps after a visit.",
			es: "Explicaciones claras de resultados, medicamentos, prevención y los pasos después de la visita."
		}
	},
	{
		icon: Compass,
		title: {
			en: "Where to go next",
			es: "A dónde seguir"
		},
		body: {
			en: "If we cannot provide a service here, we help you find a public program or another resource.",
			es: "Si no podemos ofrecer un servicio aquí, le ayudamos a encontrar un programa público u otro recurso."
		}
	}
];
function Home() {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollHero, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-ink text-cream",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "grid md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/volunteer",
					className: "border-t border-cream/15 p-8 transition-colors duration-200 hover:bg-blue-deep md:p-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-green-soft uppercase",
							children: tx({
								en: "Give time",
								es: "Dé tiempo"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-serif text-4xl",
							children: tx({
								en: "Volunteer, clinical or not.",
								es: "Voluntariado, clínico o no."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md leading-relaxed text-cream/75",
							children: tx({
								en: "Licensed clinicians use one form. Registration, phones, interpretation, and outreach use another. Interest is not a placement.",
								es: "Los clínicos con licencia usan un formulario. Registro, teléfonos, interpretación y alcance usan otro. El interés no es una colocación."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 font-medium text-cream",
							children: tx({
								en: "Choose a signup",
								es: "Elija un registro"
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/give",
					className: "border-t border-cream/15 bg-blue-deep p-8 transition-colors duration-200 hover:bg-blue md:p-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-green-soft uppercase",
							children: tx({
								en: "Give support",
								es: "Dé apoyo"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-serif text-4xl",
							children: tx({
								en: "Donate to keep the doors open.",
								es: "Done para mantener las puertas abiertas."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md leading-relaxed text-cream/75",
							children: tx({
								en: "Tell the office what you hope to support. This site does not charge a card. The office confirms the payee before any gift is mailed.",
								es: "Dígale a la oficina qué espera apoyar. Este sitio no cobra una tarjeta. La oficina confirma el beneficiario antes de enviar un donativo."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 font-medium text-cream",
							children: tx({
								en: "Start a gift",
								es: "Empezar un donativo"
							})
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-line bg-cream",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Container, {
				className: "grid gap-8 py-12 md:grid-cols-4 md:py-14",
				children: promises.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-3xl text-green",
						children: item.n
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-serif text-2xl text-ink",
						children: tx(item.title)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: tx(item.body)
					})
				] }, item.n))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid items-center gap-12 py-16 md:py-24 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				className: "lg:col-span-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
					src: "/media/chairs.jpg",
					alt: tx({
						en: "Two chairs at the same height in a quiet room. Illustrative photograph.",
						es: "Dos sillas a la misma altura en una habitación tranquila. Fotografía ilustrativa."
					}),
					className: "aspect-room w-full object-cover"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: tx({
						en: "The relationship is the care",
						es: "La relación es la atención"
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-serif text-4xl leading-tight md:text-5xl",
						children: tx({
							en: "A good visit is not a transaction.",
							es: "Una buena visita no es una transacción."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-lg leading-relaxed text-muted",
						children: tx({
							en: "It is a clinician who stays with what you are saying, explains without talking down, and does not send you out guessing. If something cannot be handled safely in this clinic, you should hear that plainly — and leave knowing where to turn.",
							es: "Es un clínico que se queda con lo que usted dice, explica sin hablarle desde arriba y no lo deja salir adivinando. Si algo no se puede atender con seguridad en esta clínica, debe escucharlo con claridad y salir sabiendo a dónde acudir."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
						className: "mt-8 border-l-2 border-green pl-5 font-serif text-2xl leading-snug text-ink",
						children: tx({
							en: "You should understand the concern, the choice in front of you, and the next step.",
							es: "Usted debe entender el problema, la decisión que tiene delante y el siguiente paso."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/visit",
						className: "mt-8 inline-flex min-h-12 items-center font-medium text-blue",
						children: tx({
							en: "See how a visit works",
							es: "Vea cómo funciona una visita"
						})
					})
				]
			})]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line bg-cream",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "py-16 md:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: tx({
							en: "What we can help with",
							es: "En qué podemos ayudar"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-serif text-4xl leading-tight",
							children: tx({
								en: "Practical care. Confirmed before you come.",
								es: "Atención práctica. Confirmada antes de que venga."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm leading-relaxed text-muted",
							children: tx({
								en: "Services depend on staffing, eligibility, and what is available that day. Call before you visit.",
								es: "Los servicios dependen del personal, la elegibilidad y lo disponible ese día. Llame antes de venir."
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 divide-y divide-line border-y border-line",
					children: services.map((service, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/services",
						className: "grid gap-4 py-6 transition-colors duration-200 hover:bg-paper md:grid-cols-12 md:items-center md:px-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-serif text-2xl text-green md:col-span-1",
								children: ["0", index + 1]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-3 font-serif text-2xl md:col-span-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(service.icon, {
									className: "size-5 text-blue",
									"aria-hidden": true
								}), tx(service.title)]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm leading-relaxed text-muted md:col-span-7",
								children: tx(service.body)
							})
						]
					}, service.title.en))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid gap-12 py-16 md:py-24 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: tx({
						en: "Become a patient",
						es: "Sea paciente"
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-serif text-4xl leading-tight",
						children: tx({
							en: "Three steps. No medical story on this website.",
							es: "Tres pasos. Ninguna historia médica en este sitio."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 leading-relaxed text-muted",
						children: tx({
							en: "Share only how to reach you. We will talk about the reason for the visit when we speak — not through an ordinary web form or email.",
							es: "Comparta solo cómo localizarle. Hablaremos del motivo de la visita cuando conversemos, no por un formulario web o un correo ordinario."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestButton, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallButton, {})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-8 lg:col-span-7",
				children: [
					{
						n: "01",
						title: {
							en: "Call or request a callback",
							es: "Llame o pida que le llamemos"
						},
						body: {
							en: "Give your name, phone, a good time of day, and the language you prefer. That is enough to start.",
							es: "Dé su nombre, teléfono, una hora conveniente y el idioma que prefiere. Con eso basta para empezar."
						}
					},
					{
						n: "02",
						title: {
							en: "We confirm what is available",
							es: "Confirmamos qué hay disponible"
						},
						body: {
							en: "The clinic tells you whether the service can be offered, what it may cost, and which papers to bring. A request is not a confirmation.",
							es: "La clínica le dice si el servicio se puede ofrecer, qué puede costar y qué papeles traer. Una solicitud no es una confirmación."
						}
					},
					{
						n: "03",
						title: {
							en: "You arrive with your questions",
							es: "Llega con sus preguntas"
						},
						body: {
							en: "Bring identification if you have it, a medication list, and the two or three questions that matter most.",
							es: "Traiga una identificación si la tiene, una lista de medicamentos y las dos o tres preguntas que más importan."
						}
					}
				].map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid grid-cols-12 gap-4 border-t border-line pt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "col-span-3 font-serif text-3xl text-green md:col-span-2",
						children: step.n
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "col-span-9 md:col-span-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-serif text-2xl",
							children: tx(step.title)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 leading-relaxed text-muted",
							children: tx(step.body)
						})]
					})]
				}, step.n))
			})]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-blue-deep text-cream",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "grid gap-10 py-16 md:grid-cols-12 md:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-green-soft",
							children: tx({
								en: "What you can verify",
								es: "Lo que puede verificar"
							})
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-serif text-4xl leading-tight",
							children: tx({
								en: "Trust should be checkable.",
								es: "La confianza debe poder comprobarse."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 leading-relaxed text-cream/80",
							children: tx({
								en: "This site does not show star ratings, awards, or staff biographies. We will not publish those unless they are verified and cleared to share. Call and ask a direct question instead.",
								es: "Este sitio no muestra calificaciones, premios ni biografías del personal. No los publicaremos salvo que estén verificados y autorizados. Llame y haga una pregunta directa."
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "md:col-span-7",
					children: [
						{
							t: {
								en: "Where and when",
								es: "Dónde y cuándo"
							},
							d: {
								en: `${clinic.street}, ${clinic.city}. Monday–Friday, 9 AM–5 PM. Closed Saturday and Sunday.`,
								es: `${clinic.street}, ${clinic.city}. Lunes a viernes, 9 AM–5 PM. Cerrado sábado y domingo.`
							}
						},
						{
							t: {
								en: "National Provider Identifier",
								es: "Identificador nacional (NPI)"
							},
							d: {
								en: `${clinic.npi}, registered as a clinic/center. You can look it up on the federal NPI registry.`,
								es: `${clinic.npi}, registrado como clínica. Puede buscarlo en el registro federal de NPI.`
							}
						},
						{
							t: {
								en: "California community clinic",
								es: "Clínica comunitaria de California"
							},
							d: {
								en: `Listed by HCAI as an open community clinic under the former name ${clinic.former}. Facility ID ${clinic.hcaiId}.`,
								es: `Figura en HCAI como clínica comunitaria abierta con el nombre anterior ${clinic.former}. ID de centro ${clinic.hcaiId}.`
							}
						},
						{
							t: {
								en: "Nonprofit",
								es: "Organización sin fines de lucro"
							},
							d: {
								en: `Canby Community Clinic Inc. is a 501(c)(3), EIN ${clinic.ein}, formed in 2022. Confirm tax details with the office before claiming a deduction.`,
								es: `Canby Community Clinic Inc. es una 501(c)(3), EIN ${clinic.ein}, formada en 2022. Confirme los datos fiscales con la oficina antes de deducir un donativo.`
							}
						}
					].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-cream/20 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm text-cream/70",
							children: tx(row.t)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 leading-relaxed",
							children: tx(row.d)
						})]
					}, row.t.en))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid gap-10 py-16 md:grid-cols-2 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: tx({
					en: "Come to the clinic",
					es: "Venga a la clínica"
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 font-serif text-4xl",
					children: tx({
						en: "Reseda, suite 6B.",
						es: "Reseda, suite 6B."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 leading-relaxed text-muted",
					children: tx({
						en: "Allow time for parking and check-in. Call if you need help finding suite 6B. Please do not arrive expecting a walk-in emergency visit.",
						es: "Tome en cuenta el estacionamiento y el registro. Llame si necesita ayuda para encontrar la suite 6B. No venga esperando una visita de emergencia sin cita."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoursTable, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: clinic.mapsUrl,
					target: "_blank",
					rel: "noreferrer",
					className: "mt-4 inline-flex min-h-12 items-center font-medium text-blue",
					children: tx({
						en: "Directions",
						es: "Cómo llegar"
					})
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-80 overflow-hidden border border-line bg-cream",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					title: tx({
						en: "Map of the clinic",
						es: "Mapa de la clínica"
					}),
					src: clinic.mapsEmbed,
					className: "h-full min-h-80 w-full",
					loading: "lazy",
					referrerPolicy: "no-referrer-when-downgrade"
				})
			})]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "grid items-center gap-8 py-16 md:grid-cols-12 md:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
					src: "/media/plan.jpg",
					alt: tx({
						en: "Hands resting on a blank notepad, suggesting a simple next-step plan. Illustrative photograph.",
						es: "Manos sobre un cuaderno en blanco, como un plan sencillo de siguientes pasos. Fotografía ilustrativa."
					}),
					className: "aspect-still w-full object-cover md:col-span-5"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-4xl leading-tight md:text-5xl",
							children: tx({
								en: "The fastest way in is the phone.",
								es: "La forma más rápida es el teléfono."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-xl text-lg leading-relaxed text-muted",
							children: tx({
								en: `Call ${clinic.phoneDisplay} on a weekday between 9 and 5. If you would rather we call you, send only your contact details.`,
								es: `Llame al ${clinic.phoneDisplay} de lunes a viernes, entre las 9 y las 5. Si prefiere que le llamemos, envíe solo sus datos de contacto.`
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallButton, { variant: "primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestButton, { variant: "secondary" })]
						})
					]
				})]
			})
		})
	] });
}
//#endregion
export { Home as component };
