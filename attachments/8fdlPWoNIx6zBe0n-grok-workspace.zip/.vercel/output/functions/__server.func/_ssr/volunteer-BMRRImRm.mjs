import { i as __toESM } from "../_runtime.mjs";
import { R as require_react, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as PageIntro, m as useTx, n as Container, p as cn } from "./ui-pby2H8c5.mjs";
import { a as MedicalVolunteerForm, i as CommunityVolunteerForm } from "./router-DgWbPDCs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/volunteer-BMRRImRm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var medicalPoints = [
	{
		en: "Physicians, nurse practitioners, physician assistants, pharmacists, nurses, and other licensed roles.",
		es: "Médicos, enfermeras practicantes, asistentes médicos, farmacéuticos, enfermería y otros roles con licencia."
	},
	{
		en: "Current licensure is required. The clinic verifies credentials before anyone sees patients.",
		es: "Se exige licencia vigente. La clínica verifica credenciales antes de que alguien atienda pacientes."
	},
	{
		en: "Work stays inside the clinic’s approved scope and supervision.",
		es: "El trabajo se queda dentro del alcance y la supervisión aprobados de la clínica."
	}
];
var communityPoints = [
	{
		en: "Registration, phones, scheduling, interpretation, outreach, and office support.",
		es: "Registro, teléfonos, citas, interpretación, alcance y apoyo de oficina."
	},
	{
		en: "No clinical license is asked for on this form.",
		es: "Este formulario no pide una licencia clínica."
	},
	{
		en: "You will be told if the role is needed, and what training comes first.",
		es: "Le diremos si el rol hace falta y qué capacitación va primero."
	}
];
function VolunteerPage() {
	const { tx } = useTx();
	const [track, setTrack] = (0, import_react.useState)("medical");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		kicker: tx({
			en: "Volunteer",
			es: "Voluntariado"
		}),
		title: tx({
			en: "Two doors. Pick the one that matches your work.",
			es: "Dos puertas. Elija la que corresponde a su trabajo."
		}),
		lede: tx({
			en: "Medical volunteers and non-medical volunteers sign up on different forms. Sending either one does not reserve a shift. The office confirms need, screening, and training.",
			es: "Los voluntarios médicos y los no médicos se registran en formularios distintos. Enviar cualquiera de los dos no reserva un turno. La oficina confirma la necesidad, la revisión y la capacitación."
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
		className: "grid gap-8 py-12 md:grid-cols-12 md:py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "md:col-span-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackButton, {
					active: track === "medical",
					kicker: tx({
						en: "Clinical",
						es: "Clínico"
					}),
					title: tx({
						en: "Medical signup",
						es: "Registro médico"
					}),
					onClick: () => setTrack("medical")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackButton, {
					active: track === "community",
					kicker: tx({
						en: "Everyone else",
						es: "Todos los demás"
					}),
					title: tx({
						en: "Non-medical signup",
						es: "Registro no médico"
					}),
					onClick: () => setTrack("community")
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 space-y-4",
				children: (track === "medical" ? medicalPoints : communityPoints).map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-l-2 border-green pl-4 text-sm leading-relaxed text-muted",
					children: tx(point)
				}, point.en))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg border border-line bg-cream p-5 md:col-span-7 md:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-3xl",
					children: track === "medical" ? tx({
						en: "Licensed clinical interest",
						es: "Interés clínico con licencia"
					}) : tx({
						en: "Non-medical interest",
						es: "Interés no médico"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 mb-6 text-sm leading-relaxed text-muted",
					children: track === "medical" ? tx({
						en: "Tell us the license you hold. Do not send patient information.",
						es: "Díganos qué licencia tiene. No envíe información de pacientes."
					}) : tx({
						en: "Tell us the desk, phone, language, or outreach work you can do.",
						es: "Díganos el trabajo de registro, teléfono, idioma o alcance que puede hacer."
					})
				}),
				track === "medical" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MedicalVolunteerForm, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommunityVolunteerForm, {})
			]
		})]
	})] });
}
function TrackButton({ active, kicker, title, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": active,
		onClick,
		className: cn("min-h-24 rounded-lg px-5 py-4 text-left ring-1", active ? "bg-ink text-cream ring-ink" : "bg-cream text-ink ring-line"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("text-xs font-medium tracking-widest uppercase", active ? "text-green-soft" : "text-green"),
			children: kicker
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-2 block font-serif text-2xl",
			children: title
		})]
	});
}
//#endregion
export { VolunteerPage as component };
