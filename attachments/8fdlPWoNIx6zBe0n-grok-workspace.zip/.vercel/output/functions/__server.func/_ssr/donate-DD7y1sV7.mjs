import { n as GivePage } from "./router-DgWbPDCs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/donate-DD7y1sV7.js
var SplitComponent = GivePage;
//#endregion
export { SplitComponent as component };
