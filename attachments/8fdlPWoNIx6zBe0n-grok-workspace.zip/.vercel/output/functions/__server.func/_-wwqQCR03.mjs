import { _ as Link, y as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { m as useTx, n as Container } from "./_ssr/ui-pby2H8c5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_-wwqQCR03.js
var import_jsx_runtime = require_jsx_runtime();
function Missing() {
	const { tx } = useTx();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
		className: "py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-widest text-green uppercase",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-serif text-5xl",
				children: tx({
					en: "That page is not here.",
					es: "Esa página no está aquí."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-md text-muted",
				children: tx({
					en: "The clinic is. Call on a weekday, or go back to the start.",
					es: "La clínica sí. Llame en un día de semana, o vuelva al inicio."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-8 inline-flex min-h-12 items-center font-medium text-blue",
				children: tx({
					en: "Back to the clinic",
					es: "Volver a la clínica"
				})
			})
		]
	});
}
//#endregion
export { Missing as component };
