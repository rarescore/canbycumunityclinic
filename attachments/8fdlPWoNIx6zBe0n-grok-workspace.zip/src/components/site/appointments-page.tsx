import { Link } from "@tanstack/react-router";
import { clinic } from "@/lib/clinic";
import { AppointmentForm } from "@/components/site/forms";
import { useTx } from "@/components/site/i18n";
import { CallButton, Container, HoursTable, Kicker } from "@/components/site/ui";

export function AppointmentsPage() {
  const { tx } = useTx();
  return (
    <>
      <Container className="grid gap-12 py-14 md:py-20 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <Kicker>{tx({ en: "Appointments", es: "Citas" })}</Kicker>
          <h1 className="mt-4 font-serif text-4xl leading-tight md:text-5xl">
            {tx({
              en: "The phone is the surest way to be seen.",
              es: "El teléfono es la forma más segura de ser atendido.",
            })}
          </h1>
          <p className="mt-5 leading-relaxed text-muted">
            {tx({
              en: "Call on a weekday and we can tell you, in the same conversation, whether we can see you, what to bring, and what the visit may cost. If you cannot call, the form prepares an email with scheduling details only.",
              es: "Llame en un día de semana y, en la misma conversación, le diremos si podemos atenderle, qué traer y cuánto puede costar la visita. Si no puede llamar, el formulario prepara un correo solo con datos para programar.",
            })}
          </p>
          <div className="mt-6">
            <CallButton variant="primary" className="w-full sm:w-auto" />
          </div>
          <div className="mt-8">
            <HoursTable />
          </div>
          <div id="contact" className="mt-8 space-y-4">
            <article className="border border-line bg-cream p-5">
              <h2 className="font-medium">{tx({ en: "Patients and appointments", es: "Pacientes y citas" })}</h2>
              <a className="mt-2 inline-flex min-h-11 items-center font-medium text-blue" href={`mailto:${clinic.emailPatients}`}>
                {clinic.emailPatients}
              </a>
              <p className="text-sm leading-relaxed text-muted">
                {tx({
                  en: "Use this address for a scheduling request or a general question about becoming a patient.",
                  es: "Use esta dirección para pedir una cita o hacer una pregunta general sobre cómo ser paciente.",
                })}
              </p>
            </article>
            <article className="border border-line bg-cream p-5">
              <h2 className="font-medium">
                {tx({ en: "Office and administration", es: "Oficina y administración" })}
              </h2>
              <a className="mt-2 inline-flex min-h-11 items-center font-medium text-blue" href={`mailto:${clinic.emailOffice}`}>
                {clinic.emailOffice}
              </a>
              <p className="text-sm leading-relaxed text-muted">
                {tx({
                  en: "Volunteers, donations, vendors, and other office matters. Not for medical details.",
                  es: "Voluntarios, donaciones, proveedores y otros asuntos de oficina. No para datos médicos.",
                })}
              </p>
            </article>
          </div>
        </div>
        <div className="lg:col-span-7">
          <h2 className="font-serif text-3xl">
            {tx({ en: "Request a callback", es: "Pida que le llamemos" })}
          </h2>
          <p className="mt-3 mb-3 text-sm leading-relaxed text-muted">
            {tx({
              en: "We ask only for what we need to contact you and suggest a time. The form does not store your information and it is not a medical record. A request is not a confirmed appointment.",
              es: "Pedimos solo lo necesario para contactarle y proponer una hora. El formulario no guarda su información y no es un expediente médico. Una solicitud no es una cita confirmada.",
            })}
          </p>
          <Link to="/privacy" className="mb-6 inline-flex min-h-11 items-center text-sm font-medium text-blue">
            {tx({ en: "Read the privacy policy", es: "Lea la política de privacidad" })}
          </Link>
          <AppointmentForm />
        </div>
      </Container>
    </>
  );
}
