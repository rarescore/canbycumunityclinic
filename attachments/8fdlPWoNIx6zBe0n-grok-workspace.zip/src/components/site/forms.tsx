import { useMemo, useState, type FormEvent, type ReactNode } from "react";
import { clinic, weekdayKeys, type Weekday } from "@/lib/clinic";
import { cn } from "@/lib/cn";
import { useTx, type L } from "@/components/site/i18n";

const days: { key: Weekday; label: L }[] = [
  { key: "mon", label: { en: "Mon", es: "Lun" } },
  { key: "tue", label: { en: "Tue", es: "Mar" } },
  { key: "wed", label: { en: "Wed", es: "Mié" } },
  { key: "thu", label: { en: "Thu", es: "Jue" } },
  { key: "fri", label: { en: "Fri", es: "Vie" } },
];

const dayName: Record<Weekday, string> = {
  mon: "Monday",
  tue: "Tuesday",
  wed: "Wednesday",
  thu: "Thursday",
  fri: "Friday",
};

type ApptState = {
  first: string;
  last: string;
  phone: string;
  email: string;
  contact: "phone" | "email" | "";
  patient: "new" | "returning" | "";
  language: "english" | "spanish" | "other" | "";
  otherLanguage: string;
  days: Weekday[];
  time: "morning" | "afternoon" | "either" | "";
  note: string;
  ack: boolean;
  website: string;
};

const emptyAppt: ApptState = {
  first: "",
  last: "",
  phone: "",
  email: "",
  contact: "",
  patient: "",
  language: "",
  otherLanguage: "",
  days: [],
  time: "",
  note: "",
  ack: false,
  website: "",
};

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-ink">{label}</span>
      <div className={cn("mt-2", error && "field-error")}>{children}</div>
      {error ? <span className="mt-1 block text-sm text-danger">{error}</span> : null}
    </label>
  );
}

const inputClass =
  "min-h-12 w-full rounded-sm border border-line bg-cream px-3 text-base text-ink outline-none transition-colors placeholder:text-muted/70 focus:border-ink";

export function AppointmentForm() {
  const { tx, lang } = useTx();
  const [state, setState] = useState<ApptState>(emptyAppt);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [ready, setReady] = useState("");
  const [copied, setCopied] = useState(false);

  const copyText = useMemo(() => (ready ? decodeMailto(ready) : ""), [ready]);

  function update<K extends keyof ApptState>(key: K, value: ApptState[K]) {
    setState((current) => ({ ...current, [key]: value }));
  }

  function toggleDay(day: Weekday) {
    setState((current) => ({
      ...current,
      days: current.days.includes(day)
        ? current.days.filter((item) => item !== day)
        : [...current.days, day],
    }));
  }

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const next = validateAppt(state, tx);
    setErrors(next);
    if (Object.keys(next).length) return;
    if (state.website.trim()) {
      setReady("blocked");
      return;
    }
    const href = buildAppointmentMailto(state);
    setReady(href);
    window.location.href = href;
  }

  if (ready && ready !== "blocked") {
    return (
      <div className="rounded-lg bg-green-soft p-6 md:p-8" role="status">
        <h2 className="font-serif text-3xl text-ink">
          {tx({ en: "Your email app should open now.", es: "Su correo debería abrirse ahora." })}
        </h2>
        <p className="mt-4 leading-relaxed text-ink">
          {tx({
            en: `Nothing from this form is saved on the website. The message is addressed to ${clinic.emailPatients}. If email does not open, call ${clinic.phoneDisplay} — that is the fastest way to be seen. A request is not a confirmed appointment.`,
            es: `Nada de este formulario se guarda en el sitio. El mensaje va dirigido a ${clinic.emailPatients}. Si el correo no se abre, llame al ${clinic.phoneDisplay}: es la forma más rápida de ser atendido. Una solicitud no es una cita confirmada.`,
          })}
        </p>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <a
            href={ready}
            className="inline-flex min-h-12 items-center justify-center rounded-lg bg-blue px-5 font-medium text-cream"
          >
            {tx({ en: "Open the email again", es: "Abrir el correo de nuevo" })}
          </a>
          <button
            type="button"
            className="inline-flex min-h-12 items-center justify-center rounded-sm bg-cream px-5 font-medium text-ink ring-1 ring-line"
            aria-live="polite"
            onClick={() => {
              void navigator.clipboard?.writeText(copyText).then(() => {
                setCopied(true);
                window.setTimeout(() => setCopied(false), 2000);
              });
            }}
          >
            {copied
              ? tx({ en: "Copied", es: "Copiado" })
              : tx({ en: "Copy the message", es: "Copiar el mensaje" })}
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="rounded-lg border border-line bg-cream p-5 md:p-8" noValidate>
      <div className="grid gap-5 md:grid-cols-2">
        <Field label={tx({ en: "First name", es: "Nombre" })} error={errors.first}>
          <input
            className={inputClass}
            autoComplete="given-name"
            autoCapitalize="words"
            value={state.first}
            onChange={(event) => update("first", event.target.value)}
          />
        </Field>
        <Field label={tx({ en: "Last name", es: "Apellido" })} error={errors.last}>
          <input
            className={inputClass}
            autoComplete="family-name"
            autoCapitalize="words"
            value={state.last}
            onChange={(event) => update("last", event.target.value)}
          />
        </Field>
        <Field label={tx({ en: "Phone", es: "Teléfono" })} error={errors.phone}>
          <input
            className={inputClass}
            autoComplete="tel"
            inputMode="tel"
            value={state.phone}
            onChange={(event) => update("phone", event.target.value)}
          />
        </Field>
        <Field label={tx({ en: "Email", es: "Correo" })} error={errors.email}>
          <input
            className={inputClass}
            autoComplete="email"
            autoCapitalize="none"
            autoCorrect="off"
            inputMode="email"
            value={state.email}
            onChange={(event) => update("email", event.target.value)}
          />
        </Field>
      </div>

      <fieldset className="mt-6">
        <legend className="text-sm font-medium text-ink">
          {tx({ en: "Best way to reach you", es: "Mejor forma de contactarle" })}
        </legend>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          <Choice
            pressed={state.contact === "phone"}
            onClick={() => update("contact", "phone")}
            label={tx({ en: "Phone", es: "Teléfono" })}
          />
          <Choice
            pressed={state.contact === "email"}
            onClick={() => update("contact", "email")}
            label={tx({ en: "Email", es: "Correo" })}
          />
        </div>
        {errors.contact ? <p className="mt-2 text-sm text-danger">{errors.contact}</p> : null}
      </fieldset>

      <fieldset className="mt-6">
        <legend className="text-sm font-medium text-ink">
          {tx({ en: "Have you been here before?", es: "¿Ha venido antes?" })}
        </legend>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          <Choice
            pressed={state.patient === "new"}
            onClick={() => update("patient", "new")}
            label={tx({ en: "New patient", es: "Paciente nuevo" })}
          />
          <Choice
            pressed={state.patient === "returning"}
            onClick={() => update("patient", "returning")}
            label={tx({ en: "I have been seen here", es: "Ya me han atendido aquí" })}
          />
        </div>
        {errors.patient ? <p className="mt-2 text-sm text-danger">{errors.patient}</p> : null}
      </fieldset>

      <fieldset className="mt-6">
        <legend className="text-sm font-medium text-ink">
          {tx({ en: "Language for the visit", es: "Idioma para la visita" })}
        </legend>
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          <Choice
            pressed={state.language === "english"}
            onClick={() => update("language", "english")}
            label={tx({ en: "English", es: "Inglés" })}
          />
          <Choice
            pressed={state.language === "spanish"}
            onClick={() => update("language", "spanish")}
            label={tx({ en: "Spanish", es: "Español" })}
          />
          <Choice
            pressed={state.language === "other"}
            onClick={() => update("language", "other")}
            label={tx({ en: "Other", es: "Otro" })}
          />
        </div>
        {state.language === "other" ? (
          <input
            className={cn(inputClass, "mt-3")}
            maxLength={40}
            placeholder={tx({ en: "Which language?", es: "¿Qué idioma?" })}
            value={state.otherLanguage}
            onChange={(event) => update("otherLanguage", event.target.value)}
          />
        ) : null}
        {errors.language ? <p className="mt-2 text-sm text-danger">{errors.language}</p> : null}
      </fieldset>

      <fieldset className="mt-6">
        <legend className="text-sm font-medium text-ink">
          {tx({ en: "Preferred weekdays", es: "Días de semana que prefiere" })}
        </legend>
        <div className="mt-3 grid grid-cols-5 gap-2">
          {days.map((day) => (
            <button
              key={day.key}
              type="button"
              aria-pressed={state.days.includes(day.key)}
              onClick={() => toggleDay(day.key)}
              className={cn(
                "min-h-12 rounded-lg text-sm font-medium ring-1",
                state.days.includes(day.key)
                  ? "bg-blue text-cream ring-blue"
                  : "bg-paper text-ink ring-line",
              )}
            >
              {tx(day.label)}
            </button>
          ))}
        </div>
        {errors.days ? <p className="mt-2 text-sm text-danger">{errors.days}</p> : null}
      </fieldset>

      <fieldset className="mt-6">
        <legend className="text-sm font-medium text-ink">
          {tx({ en: "Time of day", es: "Hora del día" })}
        </legend>
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          {(
            [
              ["morning", { en: "Morning", es: "Mañana" }],
              ["afternoon", { en: "Afternoon", es: "Tarde" }],
              ["either", { en: "Either", es: "Cualquiera" }],
            ] as const
          ).map(([key, label]) => (
            <Choice
              key={key}
              pressed={state.time === key}
              onClick={() => update("time", key)}
              label={tx(label)}
            />
          ))}
        </div>
        {errors.time ? <p className="mt-2 text-sm text-danger">{errors.time}</p> : null}
      </fieldset>

      <Field
        label={tx({
          en: "Scheduling note, optional",
          es: "Nota para programar, opcional",
        })}
        error={errors.note}
      >
        <textarea
          className={cn(inputClass, "min-h-28 py-3")}
          maxLength={280}
          value={state.note}
          onChange={(event) => update("note", event.target.value)}
          placeholder={tx({
            en: "Example: weekday mornings after 10. Do not describe symptoms or medicines.",
            es: "Ejemplo: mañanas entre semana después de las 10. No describa síntomas ni medicamentos.",
          })}
        />
        <span className="mt-1 block text-xs text-muted">{state.note.length}/280</span>
      </Field>

      <div className="sr-only" aria-hidden="true">
        <label>
          Website
          <input
            tabIndex={-1}
            autoComplete="off"
            value={state.website}
            onChange={(event) => update("website", event.target.value)}
          />
        </label>
      </div>

      <label className="mt-6 flex items-start gap-3 text-sm leading-relaxed text-ink">
        <input
          type="checkbox"
          className="mt-1 size-5 accent-blue"
          checked={state.ack}
          onChange={(event) => update("ack", event.target.checked)}
        />
        <span>
          {tx({
            en: "I understand this form only arranges a callback. I will not include symptoms, diagnoses, medications, test results, insurance numbers, or other medical details. Ordinary email is not secure for that information.",
            es: "Entiendo que este formulario solo sirve para que me llamen. No incluiré síntomas, diagnósticos, medicamentos, resultados, números de seguro ni otros datos médicos. El correo ordinario no es seguro para esa información.",
          })}
        </span>
      </label>
      {errors.ack ? <p className="mt-2 text-sm text-danger">{errors.ack}</p> : null}

      <button
        type="submit"
        className="mt-6 inline-flex min-h-12 w-full items-center justify-center rounded-lg bg-blue px-5 font-medium text-cream hover:bg-blue-deep sm:w-auto"
      >
        {tx({ en: "Prepare my email request", es: "Preparar mi solicitud por correo" })}
      </button>
      <p className="mt-3 text-xs leading-relaxed text-muted">
        {lang === "es"
          ? `Se abrirá su correo dirigido a ${clinic.emailPatients}. El sitio no guarda estos datos.`
          : `This opens your email to ${clinic.emailPatients}. The website does not store this information.`}
      </p>
    </form>
  );
}

function Choice({
  pressed,
  onClick,
  label,
}: {
  pressed: boolean;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onClick={onClick}
      className={cn(
        "min-h-12 rounded-lg px-3 text-sm font-medium ring-1",
        pressed ? "bg-blue text-cream ring-blue" : "bg-paper text-ink ring-line",
      )}
    >
      {label}
    </button>
  );
}

function validateAppt(state: ApptState, tx: (value: L) => string) {
  const errors: Record<string, string> = {};
  const required = tx({ en: "This is required.", es: "Esto es necesario." });
  if (!state.first.trim()) errors.first = required;
  if (!state.last.trim()) errors.last = required;
  if (!/^[+()\d\s.-]{7,20}$/.test(state.phone.trim())) {
    errors.phone = tx({ en: "Enter a phone number we can call.", es: "Escriba un teléfono al que podamos llamar." });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(state.email.trim())) {
    errors.email = tx({ en: "Enter a valid email.", es: "Escriba un correo válido." });
  }
  if (!state.contact) errors.contact = required;
  if (!state.patient) errors.patient = required;
  if (!state.language) errors.language = required;
  if (state.language === "other" && !state.otherLanguage.trim()) errors.language = required;
  if (!state.days.length) {
    errors.days = tx({ en: "Choose at least one weekday.", es: "Elija al menos un día." });
  }
  if (!state.time) errors.time = required;
  if (state.note.length > 280) errors.note = required;
  if (!state.ack) {
    errors.ack = tx({
      en: "Please confirm you will not include medical details.",
      es: "Confirme que no incluirá datos médicos.",
    });
  }
  return errors;
}

function buildAppointmentMailto(state: ApptState) {
  const language =
    state.language === "other"
      ? `Other: ${state.otherLanguage.trim()}`
      : state.language === "spanish"
        ? "Spanish"
        : "English";
  const body = [
    "Appointment request for Canby Community Clinic",
    "Scheduling details only — no medical information.",
    "",
    `Name: ${state.first.trim()} ${state.last.trim()}`,
    `Phone: ${state.phone.trim()}`,
    `Email: ${state.email.trim()}`,
    `Preferred contact: ${state.contact}`,
    `Patient: ${state.patient === "new" ? "New" : "Returning"}`,
    `Language: ${language}`,
    `Preferred days: ${weekdayKeys.filter((day) => state.days.includes(day)).map((day) => dayName[day]).join(", ")}`,
    `Time of day: ${state.time}`,
    `Scheduling note: ${state.note.trim() || "(none)"}`,
    "",
    "Sent from the clinic website. The sender was asked not to include symptoms, diagnoses, medications, test results, or insurance numbers.",
  ].join("\n");
  const subject = "Appointment request";
  return `mailto:${clinic.emailPatients}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

function decodeMailto(href: string) {
  const body = href.split("body=")[1] ?? "";
  try {
    return decodeURIComponent(body);
  } catch {
    return body;
  }
}

function MailReady({ href, title, body }: { href: string; title: string; body: string }) {
  const { tx } = useTx();
  return (
    <div className="rounded-lg bg-green-soft p-6" role="status">
      <h2 className="font-serif text-3xl text-ink">{title}</h2>
      <p className="mt-3 leading-relaxed text-muted">{body}</p>
      <a href={href} className="mt-5 inline-flex min-h-12 items-center font-medium text-blue">
        {tx({ en: "Open the email again", es: "Abrir el correo de nuevo" })}
      </a>
    </div>
  );
}

function Chip({
  pressed,
  label,
  onClick,
}: {
  pressed: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onClick={onClick}
      className={cn(
        "min-h-12 rounded-lg px-3 text-left text-sm font-medium ring-1",
        pressed ? "bg-blue text-cream ring-blue" : "bg-paper text-ink ring-line",
      )}
    >
      {label}
    </button>
  );
}

const emailOk = (value: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());

export function MedicalVolunteerForm() {
  const { tx } = useTx();
  const roles: { id: string; label: L }[] = [
    { id: "Physician", label: { en: "Physician", es: "Médico" } },
    { id: "Nurse practitioner", label: { en: "Nurse practitioner", es: "Enfermera practicante" } },
    { id: "Physician assistant", label: { en: "Physician assistant", es: "Asistente médico" } },
    { id: "Pharmacist", label: { en: "Pharmacist", es: "Farmacéutico" } },
    { id: "Nurse", label: { en: "Nurse", es: "Enfermería" } },
    { id: "Other licensed role", label: { en: "Other licensed role", es: "Otro rol con licencia" } },
  ];
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState("");
  const [license, setLicense] = useState("");
  const [licenseState, setLicenseState] = useState("");
  const [languages, setLanguages] = useState("");
  const [availability, setAvailability] = useState("");
  const [website, setWebsite] = useState("");
  const [error, setError] = useState("");
  const [href, setHref] = useState("");

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!name.trim() || !emailOk(email) || !phone.trim() || !role || !license.trim() || !licenseState.trim()) {
      setError(
        tx({
          en: "Name, email, phone, role, license type, and license state are required.",
          es: "El nombre, correo, teléfono, rol, tipo de licencia y estado de la licencia son necesarios.",
        }),
      );
      return;
    }
    setError("");
    if (website.trim()) {
      setHref("blocked");
      return;
    }
    const body = [
      "MEDICAL volunteer interest — Canby Community Clinic",
      "Credential information only. No patient information.",
      "",
      `Name: ${name.trim()}`,
      `Email: ${email.trim()}`,
      `Phone: ${phone.trim()}`,
      `Role: ${role}`,
      `License type: ${license.trim()}`,
      `License state: ${licenseState.trim()}`,
      `Languages: ${languages.trim() || "(not given)"}`,
      `Availability: ${availability.trim() || "(not given)"}`,
      "",
      "Interest is not a placement. Licensure will be verified by the clinic.",
    ].join("\n");
    const next = `mailto:${clinic.emailOffice}?subject=${encodeURIComponent("Medical volunteer interest")}&body=${encodeURIComponent(body)}`;
    setHref(next);
    window.location.href = next;
  }

  if (href && href !== "blocked") {
    return (
      <MailReady
        href={href}
        title={tx({ en: "Email the office", es: "Escriba a la oficina" })}
        body={tx({
          en: `Your email app should open a message to ${clinic.emailOffice}. A licensed role still needs credential review. This is not a placement.`,
          es: `Su correo debería abrir un mensaje a ${clinic.emailOffice}. Un rol con licencia aún requiere revisión de credenciales. Esto no es una colocación.`,
        })}
      />
    );
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-5" noValidate>
      <Field label={tx({ en: "Full name", es: "Nombre completo" })}>
        <input className={inputClass} autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} />
      </Field>
      <div className="grid gap-5 md:grid-cols-2">
        <Field label={tx({ en: "Email", es: "Correo" })}>
          <input className={inputClass} inputMode="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} />
        </Field>
        <Field label={tx({ en: "Phone", es: "Teléfono" })}>
          <input className={inputClass} inputMode="tel" autoComplete="tel" value={phone} onChange={(event) => setPhone(event.target.value)} />
        </Field>
      </div>
      <fieldset>
        <legend className="text-sm font-medium text-ink">{tx({ en: "Licensed role", es: "Rol con licencia" })}</legend>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {roles.map((item) => (
            <Chip key={item.id} pressed={role === item.id} label={tx(item.label)} onClick={() => setRole(item.id)} />
          ))}
        </div>
      </fieldset>
      <div className="grid gap-5 md:grid-cols-2">
        <Field label={tx({ en: "License type", es: "Tipo de licencia" })}>
          <input
            className={inputClass}
            value={license}
            placeholder={tx({ en: "MD, DO, NP, PA, RN, RPh…", es: "MD, DO, NP, PA, RN, RPh…" })}
            onChange={(event) => setLicense(event.target.value)}
          />
        </Field>
        <Field label={tx({ en: "License state", es: "Estado de la licencia" })}>
          <input className={inputClass} value={licenseState} placeholder="CA" onChange={(event) => setLicenseState(event.target.value)} />
        </Field>
      </div>
      <Field label={tx({ en: "Languages", es: "Idiomas" })}>
        <input className={inputClass} value={languages} onChange={(event) => setLanguages(event.target.value)} />
      </Field>
      <Field label={tx({ en: "When you can be here", es: "Cuándo puede estar aquí" })}>
        <textarea className={cn(inputClass, "min-h-24 py-3")} maxLength={280} value={availability} onChange={(event) => setAvailability(event.target.value)} />
      </Field>
      <Honeypot value={website} onChange={setWebsite} />
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <button type="submit" className="inline-flex min-h-12 items-center justify-center rounded-lg bg-blue px-5 font-medium text-cream">
        {tx({ en: "Email medical volunteer interest", es: "Enviar interés clínico" })}
      </button>
      <p className="text-xs leading-relaxed text-muted">
        {tx({
          en: `Opens an email to ${clinic.emailOffice}. Do not include patient names or medical records. The clinic verifies licensure before anyone sees patients.`,
          es: `Abre un correo a ${clinic.emailOffice}. No incluya nombres de pacientes ni expedientes. La clínica verifica la licencia antes de que alguien atienda pacientes.`,
        })}
      </p>
    </form>
  );
}

export function CommunityVolunteerForm() {
  const { tx } = useTx();
  const roles: { id: string; label: L }[] = [
    { id: "Registration", label: { en: "Registration", es: "Registro" } },
    { id: "Phones and scheduling", label: { en: "Phones and scheduling", es: "Teléfonos y citas" } },
    { id: "Interpretation", label: { en: "Interpretation", es: "Interpretación" } },
    { id: "Outreach", label: { en: "Outreach", es: "Alcance comunitario" } },
    { id: "Administration", label: { en: "Administration", es: "Administración" } },
    { id: "Another non-clinical role", label: { en: "Another non-clinical role", es: "Otro rol no clínico" } },
  ];
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState("");
  const [languages, setLanguages] = useState("");
  const [availability, setAvailability] = useState("");
  const [website, setWebsite] = useState("");
  const [error, setError] = useState("");
  const [href, setHref] = useState("");

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!name.trim() || !emailOk(email) || !phone.trim() || !role) {
      setError(tx({ en: "Name, email, phone, and role are required.", es: "El nombre, correo, teléfono y rol son necesarios." }));
      return;
    }
    setError("");
    if (website.trim()) {
      setHref("blocked");
      return;
    }
    const body = [
      "NON-MEDICAL volunteer interest — Canby Community Clinic",
      "",
      `Name: ${name.trim()}`,
      `Email: ${email.trim()}`,
      `Phone: ${phone.trim()}`,
      `Role: ${role}`,
      `Languages: ${languages.trim() || "(not given)"}`,
      `Availability: ${availability.trim() || "(not given)"}`,
      "",
      "Interest is not a placement. Do not include patient information.",
    ].join("\n");
    const next = `mailto:${clinic.emailOffice}?subject=${encodeURIComponent("Non-medical volunteer interest")}&body=${encodeURIComponent(body)}`;
    setHref(next);
    window.location.href = next;
  }

  if (href && href !== "blocked") {
    return (
      <MailReady
        href={href}
        title={tx({ en: "Email the office", es: "Escriba a la oficina" })}
        body={tx({
          en: `Your email app should open a message to ${clinic.emailOffice}. The clinic will say whether this role is needed right now.`,
          es: `Su correo debería abrir un mensaje a ${clinic.emailOffice}. La clínica dirá si este rol hace falta ahora.`,
        })}
      />
    );
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-5" noValidate>
      <Field label={tx({ en: "Full name", es: "Nombre completo" })}>
        <input className={inputClass} autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} />
      </Field>
      <div className="grid gap-5 md:grid-cols-2">
        <Field label={tx({ en: "Email", es: "Correo" })}>
          <input className={inputClass} inputMode="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} />
        </Field>
        <Field label={tx({ en: "Phone", es: "Teléfono" })}>
          <input className={inputClass} inputMode="tel" autoComplete="tel" value={phone} onChange={(event) => setPhone(event.target.value)} />
        </Field>
      </div>
      <fieldset>
        <legend className="text-sm font-medium text-ink">{tx({ en: "How you want to help", es: "Cómo quiere ayudar" })}</legend>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {roles.map((item) => (
            <Chip key={item.id} pressed={role === item.id} label={tx(item.label)} onClick={() => setRole(item.id)} />
          ))}
        </div>
      </fieldset>
      <Field label={tx({ en: "Languages", es: "Idiomas" })}>
        <input className={inputClass} value={languages} onChange={(event) => setLanguages(event.target.value)} />
      </Field>
      <Field label={tx({ en: "When you are usually free", es: "Cuándo suele estar disponible" })}>
        <textarea className={cn(inputClass, "min-h-24 py-3")} maxLength={280} value={availability} onChange={(event) => setAvailability(event.target.value)} />
      </Field>
      <Honeypot value={website} onChange={setWebsite} />
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <button type="submit" className="inline-flex min-h-12 items-center justify-center rounded-lg bg-green px-5 font-medium text-cream">
        {tx({ en: "Email non-medical interest", es: "Enviar interés no clínico" })}
      </button>
      <p className="text-xs leading-relaxed text-muted">
        {tx({
          en: `Opens an email to ${clinic.emailOffice}. Do not include anyone else’s medical information.`,
          es: `Abre un correo a ${clinic.emailOffice}. No incluya información médica de otra persona.`,
        })}
      </p>
    </form>
  );
}

export function DonateForm() {
  const { tx } = useTx();
  const amounts = ["50", "100", "250", "500", "other"] as const;
  const funds: { id: string; label: L }[] = [
    { id: "Wherever it is needed", label: { en: "Wherever it is needed", es: "Donde haga falta" } },
    { id: "Medical supplies", label: { en: "Medical supplies", es: "Insumos médicos" } },
    { id: "Medications", label: { en: "Medications", es: "Medicamentos" } },
    { id: "Health education", label: { en: "Health education", es: "Educación en salud" } },
    { id: "Operations", label: { en: "Keeping the clinic open", es: "Mantener la clínica abierta" } },
  ];
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [amount, setAmount] = useState("");
  const [other, setOther] = useState("");
  const [fund, setFund] = useState("Wherever it is needed");
  const [note, setNote] = useState("");
  const [ack, setAck] = useState(false);
  const [website, setWebsite] = useState("");
  const [error, setError] = useState("");
  const [href, setHref] = useState("");

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const gift = amount === "other" ? other.trim() : amount ? `$${amount}` : "";
    if (!name.trim() || !emailOk(email) || !gift || !ack) {
      setError(
        tx({
          en: "Name, email, an amount, and the confirmation are required.",
          es: "El nombre, el correo, un monto y la confirmación son necesarios.",
        }),
      );
      return;
    }
    setError("");
    if (website.trim()) {
      setHref("blocked");
      return;
    }
    const body = [
      "Donation interest — Canby Community Clinic",
      "This message does not charge a card and is not a completed gift.",
      "",
      `Name: ${name.trim()}`,
      `Email: ${email.trim()}`,
      `Phone: ${phone.trim() || "(not given)"}`,
      `Intended amount: ${gift}`,
      `Hope to support: ${fund}`,
      `Note: ${note.trim() || "(none)"}`,
      "",
      "Please confirm the legal payee, EIN 87-1610266, and how to complete the gift.",
    ].join("\n");
    const next = `mailto:${clinic.emailOffice}?subject=${encodeURIComponent("Donation interest")}&body=${encodeURIComponent(body)}`;
    setHref(next);
    window.location.href = next;
  }

  if (href && href !== "blocked") {
    return (
      <MailReady
        href={href}
        title={tx({ en: "The office has to confirm the gift.", es: "La oficina debe confirmar el donativo." })}
        body={tx({
          en: `Nothing was charged. Your email app should open a note to ${clinic.emailOffice}. Wait for the legal payee before you mail a check.`,
          es: `No se cobró nada. Su correo debería abrir una nota a ${clinic.emailOffice}. Espere el beneficiario legal antes de enviar un cheque.`,
        })}
      />
    );
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-5" noValidate>
      <Field label={tx({ en: "Name", es: "Nombre" })}>
        <input className={inputClass} autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} />
      </Field>
      <div className="grid gap-5 md:grid-cols-2">
        <Field label={tx({ en: "Email", es: "Correo" })}>
          <input className={inputClass} inputMode="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} />
        </Field>
        <Field label={tx({ en: "Phone, optional", es: "Teléfono, opcional" })}>
          <input className={inputClass} inputMode="tel" autoComplete="tel" value={phone} onChange={(event) => setPhone(event.target.value)} />
        </Field>
      </div>
      <fieldset>
        <legend className="text-sm font-medium text-ink">{tx({ en: "Amount you have in mind", es: "Monto que tiene en mente" })}</legend>
        <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-5">
          {amounts.map((item) => (
            <Chip
              key={item}
              pressed={amount === item}
              label={item === "other" ? tx({ en: "Other", es: "Otro" }) : `$${item}`}
              onClick={() => setAmount(item)}
            />
          ))}
        </div>
        {amount === "other" ? (
          <input
            className={cn(inputClass, "mt-3")}
            inputMode="decimal"
            placeholder={tx({ en: "Amount", es: "Monto" })}
            value={other}
            onChange={(event) => setOther(event.target.value)}
          />
        ) : null}
      </fieldset>
      <fieldset>
        <legend className="text-sm font-medium text-ink">{tx({ en: "What you hope it supports", es: "Qué espera que apoye" })}</legend>
        <div className="mt-3 grid gap-2">
          {funds.map((item) => (
            <Chip key={item.id} pressed={fund === item.id} label={tx(item.label)} onClick={() => setFund(item.id)} />
          ))}
        </div>
      </fieldset>
      <Field label={tx({ en: "Note, optional", es: "Nota, opcional" })}>
        <textarea className={cn(inputClass, "min-h-24 py-3")} maxLength={280} value={note} onChange={(event) => setNote(event.target.value)} />
      </Field>
      <label className="flex items-start gap-3 text-sm leading-relaxed text-ink">
        <input type="checkbox" className="mt-1 size-5 accent-blue" checked={ack} onChange={(event) => setAck(event.target.checked)} />
        <span>
          {tx({
            en: "I understand this form does not charge a card or complete a donation. The office will confirm the legal name and payee before I send anything.",
            es: "Entiendo que este formulario no cobra una tarjeta ni completa un donativo. La oficina confirmará el nombre legal y el beneficiario antes de que yo envíe algo.",
          })}
        </span>
      </label>
      <Honeypot value={website} onChange={setWebsite} />
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <button type="submit" className="inline-flex min-h-12 items-center justify-center rounded-lg bg-blue px-5 font-medium text-cream">
        {tx({ en: "Email the office about a gift", es: "Escribir a la oficina sobre un donativo" })}
      </button>
    </form>
  );
}

function Honeypot({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return (
    <div className="sr-only" aria-hidden="true">
      <label>
        Website
        <input tabIndex={-1} autoComplete="off" value={value} onChange={(event) => onChange(event.target.value)} />
      </label>
    </div>
  );
}
