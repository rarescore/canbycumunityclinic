import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { clinic } from "@/lib/clinic";
import { cn } from "@/lib/cn";
import { useTx, type L } from "@/components/site/i18n";
import { CallButton, Container, RequestButton } from "@/components/site/ui";

const nav: { to: "/services" | "/visit" | "/volunteer" | "/give"; label: L }[] = [
  { to: "/services", label: { en: "Services", es: "Servicios" } },
  { to: "/visit", label: { en: "Your visit", es: "Su visita" } },
  { to: "/volunteer", label: { en: "Volunteer", es: "Voluntariado" } },
  { to: "/give", label: { en: "Donate", es: "Donar" } },
];

const directory: { to: "/" | "/services" | "/visit" | "/appointments" | "/about" | "/resources" | "/volunteer" | "/give" | "/privacy" | "/terms"; label: L }[] = [
  { to: "/", label: { en: "Home", es: "Inicio" } },
  { to: "/services", label: { en: "Services", es: "Servicios" } },
  { to: "/visit", label: { en: "Your visit", es: "Su visita" } },
  { to: "/appointments", label: { en: "Appointments", es: "Citas" } },
  { to: "/about", label: { en: "About", es: "Nosotros" } },
  { to: "/resources", label: { en: "Resources", es: "Recursos" } },
  { to: "/volunteer", label: { en: "Volunteer", es: "Voluntariado" } },
  { to: "/give", label: { en: "Donate", es: "Donar" } },
  { to: "/privacy", label: { en: "Privacy", es: "Privacidad" } },
  { to: "/terms", label: { en: "Terms", es: "Términos" } },
];

function LangToggle() {
  const { lang, setLang, tx } = useTx();
  return (
    <div className="flex items-center" role="group" aria-label={tx({ en: "Language", es: "Idioma" })}>
      {(["en", "es"] as const).map((code, index) => (
        <span key={code} className="inline-flex items-center">
          {index === 1 ? <span className="text-line" aria-hidden>/</span> : null}
          <button
          type="button"
          aria-pressed={lang === code}
          onClick={() => setLang(code)}
          className={cn(
            "min-h-11 min-w-11 text-xs font-medium tracking-widest",
            lang === code ? "text-ink" : "text-muted hover:text-ink",
            index === 0 && "text-right",
          )}
        >
          {code === "en" ? "EN" : "ES"}
        </button>
        </span>
      ))}
    </div>
  );
}

export function SiteFrame({ children }: { children: ReactNode }) {
  const { tx } = useTx();
  return (
    <div className="flex min-h-dvh flex-col bg-paper pb-24 text-ink md:pb-0">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:bg-cream focus:px-4 focus:py-3"
      >
        {tx({ en: "Skip to content", es: "Saltar al contenido" })}
      </a>
      <EmergencyBar />
      <Header />
      <main id="main" className="flex-1">
        {children}
      </main>
      <Footer />
      <MobileDock />
    </div>
  );
}

function EmergencyBar() {
  const { tx } = useTx();
  return (
    <div className="no-print bg-ink text-cream">
      <Container className="py-2 text-center text-xs leading-relaxed md:text-sm">
        {tx({
          en: "Medical emergency? Call 911. This is not an emergency department, and this website is not monitored for emergencies.",
          es: "¿Emergencia médica? Llame al 911. Esto no es una sala de emergencias y este sitio no se vigila para emergencias.",
        })}
      </Container>
    </div>
  );
}

function Header() {
  const { tx } = useTx();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setScrolled(window.scrollY > 12);
      setProgress(max > 0 ? Math.min(1, window.scrollY / max) : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    const previous = document.activeElement as HTMLElement | null;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
      previous?.focus();
    };
  }, [open]);

  return (
    <header
      className={cn(
        "relative sticky top-0 z-40 border-b border-line bg-cream/90 backdrop-blur-md transition-shadow duration-200",
        scrolled && "shadow-[0_10px_30px_rgb(22_29_39/0.06)]",
      )}
    >
      <div
        className="read-progress absolute inset-x-0 bottom-0 h-px origin-left bg-green"
        style={{ transform: `scaleX(${progress})` }}
        aria-hidden
      />
      <Container className="flex min-h-16 items-center gap-6 py-2 md:min-h-20">
        <Link to="/" className="shrink-0" aria-label={clinic.name} onClick={() => setOpen(false)}>
          <img
            src="/media/logo.png"
            alt={clinic.name}
            className="h-10 w-auto max-w-44 object-contain object-left md:h-12 md:max-w-52"
          />
        </Link>
        <nav className="ml-auto hidden items-center gap-7 lg:flex" aria-label="Primary">
          {nav.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="border-b border-transparent pb-0.5 text-xs font-medium tracking-widest text-muted uppercase hover:text-ink"
              activeProps={{ className: "border-b border-ink pb-0.5 text-xs font-medium tracking-widest text-ink uppercase" }}
            >
              {tx(item.label)}
            </Link>
          ))}
        </nav>
        <div className="ml-auto hidden items-center gap-4 lg:flex">
          <LangToggle />
          <a
            href={`tel:${clinic.phoneTel}`}
            className="text-sm font-medium text-ink tabular-nums hover:text-blue"
          >
            {clinic.phoneDisplay}
          </a>
          <RequestButton variant="secondary" className="min-h-11 px-4 text-sm" />
        </div>
        <div className="ml-auto flex items-center gap-1 lg:hidden">
          <LangToggle />
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center"
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={tx({ en: open ? "Close menu" : "Open menu", es: open ? "Cerrar menú" : "Abrir menú" })}
            onClick={() => setOpen((value) => !value)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </Container>
      {open ? (
        <div
          id="mobile-menu"
          className="border-t border-line bg-cream lg:hidden"
          role="dialog"
          aria-modal="true"
          aria-label={tx({ en: "Menu", es: "Menú" })}
        >
          <Container className="flex flex-col gap-1 py-4">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="min-h-12 rounded-lg px-2 py-3 text-lg text-ink"
                activeProps={{ className: "min-h-12 rounded-lg bg-blue-soft px-2 py-3 text-lg text-blue" }}
              >
                {tx(item.label)}
              </Link>
            ))}
            <Link
              to="/about"
              onClick={() => setOpen(false)}
              className="min-h-12 rounded-lg px-2 py-3 text-lg text-ink"
            >
              {tx({ en: "About", es: "Nosotros" })}
            </Link>
            <Link
              to="/resources"
              onClick={() => setOpen(false)}
              className="min-h-12 rounded-lg px-2 py-3 text-lg text-ink"
            >
              {tx({ en: "Resources", es: "Recursos" })}
            </Link>
            <Link
              to="/appointments"
              onClick={() => setOpen(false)}
              className="min-h-12 rounded-lg px-2 py-3 text-lg text-ink"
            >
              {tx({ en: "Appointments", es: "Citas" })}
            </Link>
            <div className="mt-3 flex flex-col gap-2">
              <CallButton />
              <RequestButton />
            </div>
          </Container>
        </div>
      ) : null}
    </header>
  );
}

function Footer() {
  const { tx } = useTx();
  return (
    <footer className="border-t border-line bg-cream">
      <Container className="grid gap-10 py-14 md:grid-cols-12">
        <div className="md:col-span-4">
          <img src="/media/logo.png" alt="" className="h-14 w-auto" />
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted">
            {tx({
              en: `Formerly ${clinic.former}. A community clinic in Reseda.`,
              es: `Antes ${clinic.former}. Una clínica comunitaria en Reseda.`,
            })}
          </p>
          <p className="mt-4 max-w-xs text-xs leading-relaxed text-muted">
            {tx({
              en: "Photographs on this website are illustrative. They are not pictures of our building, staff, or patients.",
              es: "Las fotografías de este sitio son ilustrativas. No son imágenes de nuestro edificio, personal ni pacientes.",
            })}
          </p>
        </div>
        <div className="md:col-span-4">
          <h2 className="text-sm font-medium text-ink">{tx({ en: "Visit", es: "Visítenos" })}</h2>
          <address className="mt-3 text-sm leading-relaxed text-muted not-italic">
            {clinic.street}
            <br />
            {clinic.city}
          </address>
          <p className="mt-3 text-sm text-muted">
            {tx({ en: "Monday–Friday, 9 AM–5 PM", es: "Lunes a viernes, 9 AM–5 PM" })}
            <br />
            {tx({ en: "Saturday and Sunday, closed", es: "Sábado y domingo, cerrado" })}
          </p>
          <a
            href={clinic.mapsUrl}
            className="mt-3 inline-flex min-h-11 items-center text-sm font-medium text-blue"
            target="_blank"
            rel="noopener noreferrer"
          >
            {tx({ en: "Open in Maps", es: "Abrir en Maps" })}
          </a>
        </div>
        <div className="md:col-span-4">
          <h2 className="text-sm font-medium text-ink">{tx({ en: "Which contact to use", es: "Qué contacto usar" })}</h2>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            {tx({ en: "Patients and appointments", es: "Pacientes y citas" })}
          </p>
          <a className="text-sm font-medium break-all text-blue" href={`mailto:${clinic.emailPatients}`}>
            {clinic.emailPatients}
          </a>
          <p className="mt-1 text-sm">
            <a className="font-medium text-blue tabular-nums" href={`tel:${clinic.phoneTel}`}>
              {clinic.phoneDisplay}
            </a>
          </p>
          <p className="mt-4 text-sm leading-relaxed text-muted">
            {tx({ en: "Office, volunteers, and gifts", es: "Oficina, voluntarios y donaciones" })}
          </p>
          <a className="text-sm font-medium break-all text-blue" href={`mailto:${clinic.emailOffice}`}>
            {clinic.emailOffice}
          </a>
          <p className="mt-4 text-xs leading-relaxed text-danger">
            {tx({
              en: "Do not email symptoms, diagnoses, test results, insurance ID numbers, Social Security numbers, or medical records. Ordinary email is not a secure medical channel.",
              es: "No envíe por correo síntomas, diagnósticos, resultados, números de seguro, números de Seguro Social ni expedientes. El correo ordinario no es un canal médico seguro.",
            })}
          </p>
        </div>
      </Container>
      <div className="border-t border-line">
        <Container className="flex flex-col gap-4 py-5 md:flex-row md:items-center md:justify-between">
          <p className="text-xs text-muted">
            © {new Date().getFullYear()} {clinic.name}
          </p>
          <nav className="flex flex-wrap gap-x-4 gap-y-2" aria-label="Footer">
            {directory.map((item) => (
              <Link key={item.to} to={item.to} className="text-xs font-medium text-muted hover:text-ink">
                {tx(item.label)}
              </Link>
            ))}
          </nav>
        </Container>
      </div>
    </footer>
  );
}

function MobileDock() {
  const { tx } = useTx();
  return (
    <div className="no-print fixed inset-x-0 bottom-0 z-30 border-t border-line bg-cream/95 p-3 backdrop-blur md:hidden">
      <div className="grid grid-cols-2 gap-2 pr-14">
        <CallButton className="px-2 text-sm" />
        <Link
          to="/appointments"
          className="inline-flex min-h-12 items-center justify-center rounded-sm bg-blue px-2 text-sm font-medium text-cream"
        >
          {tx({ en: "Request", es: "Solicitar" })}
        </Link>
      </div>
    </div>
  );
}
