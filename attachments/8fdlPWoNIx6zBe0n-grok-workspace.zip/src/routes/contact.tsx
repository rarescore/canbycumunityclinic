import { createFileRoute } from "@tanstack/react-router";
import { AppointmentsPage } from "@/components/site/appointments-page";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact | Canby Community Clinic" },
      {
        name: "description",
        content:
          "Contact Canby Community Clinic in Reseda. Patients: Info@canbycc.org or (818) 674-4414. Office: office@canbycc.org. Do not email medical information.",
      },
    ],
  }),
  component: AppointmentsPage,
});
