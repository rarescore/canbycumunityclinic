import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, Compass, HeartPulse, Pill, Stethoscope, TestTube } from "lucide-react";
import { clinic } from "@/lib/clinic";
import { useTx, type L } from "@/components/site/i18n";
import { ScrollHero } from "@/components/site/scroll-hero";
import {
  CallButton,
  Container,
  HoursTable,
  Kicker,
  IllustrativeNote,
  Photo,
  RequestButton,
  Reveal,
} from "@/components/site/ui";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Canby Community Clinic | Reseda" },
      {
        name: "description",
        content:
          "Canby Community Clinic, formerly Pura Vida, in Reseda. A weekday visit built around listening, a clear explanation, and a plan for what happens next. Call (818) 674-4414.",
      },
    ],
  }),
  component: Home,
});

const promises: { n: string; title: L; body: L }[] = [
  {
    n: "01",
    title: { en: "You are listened to", es: "Lo escuchamos" },
    body: {
      en: "The visit starts with your story, your medicines, and the question you actually came in with.",
      es: "La visita empieza con su historia, sus medicamentos y la pregunta con la que realmente llegó.",
    },
  },
  {
    n: "02",
    title: { en: "There is time to talk", es: "Hay tiempo para hablar" },
    body: {
      en: "The visit is organized so the conversation is not a race to the door. We do not publish a minute count we cannot stand behind.",
      es: "La visita se organiza para que la conversación no sea una carrera hacia la puerta. No publicamos un número de minutos que no podamos sostener.",
    },
  },
  {
    n: "03",
    title: { en: "You understand it", es: "Usted lo entiende" },
    body: {
      en: "Findings and choices are explained in ordinary language, in English or Spanish.",
      es: "Los hallazgos y las opciones se explican en lenguaje sencillo, en inglés o en español.",
    },
  },
  {
    n: "04",
    title: { en: "You leave with a direction", es: "Se va con una dirección" },
    body: {
      en: "A treatment, a test, a referral, or another resource — named, so you know what happens next.",
      es: "Un tratamiento, una prueba, una referencia u otro recurso, con nombre, para que sepa qué sigue.",
    },
  },
];

const services: { icon: typeof Stethoscope; title: L; body: L }[] = [
  {
    icon: Stethoscope,
    title: { en: "Primary care", es: "Atención primaria" },
    body: {
      en: "A general visit, follow-up, medication review, and a referral when you need one.",
      es: "Una visita general, seguimiento, revisión de medicamentos y una referencia cuando haga falta.",
    },
  },
  {
    icon: HeartPulse,
    title: { en: "Preventive checks", es: "Revisiones preventivas" },
    body: {
      en: "Blood pressure, diabetes risk, and preventive guidance matched to age and history.",
      es: "Presión arterial, riesgo de diabetes y orientación preventiva según la edad y la historia.",
    },
  },
  {
    icon: TestTube,
    title: { en: "Labs and tests", es: "Laboratorios y pruebas" },
    body: {
      en: "Help arranging basic tests when they are clinically appropriate. Fees are confirmed first.",
      es: "Ayuda para coordinar pruebas básicas cuando son apropiadas. Las tarifas se confirman antes.",
    },
  },
  {
    icon: Pill,
    title: { en: "Medication help", es: "Ayuda con medicamentos" },
    body: {
      en: "Help understanding a prescription or finding certain medicines. Nothing is guaranteed in stock.",
      es: "Ayuda para entender una receta o encontrar ciertos medicamentos. Nada está garantizado en existencia.",
    },
  },
  {
    icon: BookOpen,
    title: { en: "Health education", es: "Educación en salud" },
    body: {
      en: "Plain explanations of results, medicines, prevention, and the steps after a visit.",
      es: "Explicaciones claras de resultados, medicamentos, prevención y los pasos después de la visita.",
    },
  },
  {
    icon: Compass,
    title: { en: "Where to go next", es: "A dónde seguir" },
    body: {
      en: "If we cannot provide a service here, we help you find a public program or another resource.",
      es: "Si no podemos ofrecer un servicio aquí, le ayudamos a encontrar un programa público u otro recurso.",
    },
  },
];

function Home() {
  const { tx } = useTx();

  return (
    <>
      <ScrollHero />

      <section className="border-b border-line bg-cream">
        <Container className="grid md:grid-cols-2">
          <Link to="/volunteer" className="group border-b border-line py-12 md:border-r md:border-b-0 md:py-20 md:pr-12">
            <p className="text-xs font-medium tracking-widest text-ink uppercase">
              {tx({ en: "Time", es: "Tiempo" })}
            </p>
            <h2 className="mt-4 font-serif text-4xl leading-tight md:text-5xl">
              {tx({ en: "Volunteer.", es: "Voluntariado." })}
            </h2>
            <p className="mt-4 max-w-sm leading-relaxed text-muted">
              {tx({
                en: "A medical form for licensed clinicians. A separate form for registration, phones, interpretation, and outreach.",
                es: "Un formulario médico para clínicos con licencia. Otro para registro, teléfonos, interpretación y alcance.",
              })}
            </p>
            <p className="mt-8 text-sm font-medium tracking-wide text-ink uppercase transition-transform duration-200 group-hover:translate-x-1">
              {tx({ en: "Choose a signup", es: "Elija un registro" })}
            </p>
          </Link>
          <Link to="/give" className="group py-12 md:py-20 md:pl-12">
            <p className="text-xs font-medium tracking-widest text-ink uppercase">
              {tx({ en: "Support", es: "Apoyo" })}
            </p>
            <h2 className="mt-4 font-serif text-4xl leading-tight md:text-5xl">
              {tx({ en: "Donate.", es: "Done." })}
            </h2>
            <p className="mt-4 max-w-sm leading-relaxed text-muted">
              {tx({
                en: "Say what you hope to support. Nothing here charges a card. The office confirms the payee first.",
                es: "Diga qué espera apoyar. Aquí no se cobra ninguna tarjeta. La oficina confirma el beneficiario primero.",
              })}
            </p>
            <p className="mt-8 text-sm font-medium tracking-wide text-ink uppercase transition-transform duration-200 group-hover:translate-x-1">
              {tx({ en: "Start a gift", es: "Empezar un donativo" })}
            </p>
          </Link>
        </Container>
      </section>

      <section className="border-b border-line">
        <Container className="py-16 md:py-24">
          <div className="grid gap-10 md:grid-cols-12">
            <h2 className="font-serif text-4xl leading-tight md:col-span-4 md:text-5xl">
              {tx({ en: "What a visit is for.", es: "Para qué es una visita." })}
            </h2>
            <ol className="md:col-span-8">
              {promises.map((item) => (
                <li key={item.n} className="grid grid-cols-12 gap-4 border-t border-line py-6">
                  <span className="col-span-2 font-serif text-lg text-muted md:col-span-1">{item.n}</span>
                  <div className="col-span-10 md:col-span-4">
                    <h3 className="font-serif text-2xl leading-tight">{tx(item.title)}</h3>
                  </div>
                  <p className="col-span-10 col-start-3 text-sm leading-relaxed text-muted md:col-span-7 md:col-start-6">
                    {tx(item.body)}
                  </p>
                </li>
              ))}
            </ol>
          </div>
        </Container>
      </section>

      <section>
        <Container className="grid items-center gap-12 py-16 md:py-24 lg:grid-cols-12">
          <Reveal className="lg:col-span-5">
            <Photo
              src="/media/chairs.jpg"
              alt={tx({
                en: "Two chairs at the same height in a quiet room. Illustrative photograph.",
                es: "Dos sillas a la misma altura en una habitación tranquila. Fotografía ilustrativa.",
              })}
              className="aspect-room w-full object-cover"
            />
            <div className="mt-3">
              <IllustrativeNote />
            </div>
          </Reveal>
          <div className="lg:col-span-7">
            <Kicker>{tx({ en: "The relationship is the care", es: "La relación es la atención" })}</Kicker>
            <h2 className="mt-4 font-serif text-4xl leading-tight md:text-5xl">
              {tx({
                en: "A good visit is not a transaction.",
                es: "Una buena visita no es una transacción.",
              })}
            </h2>
            <p className="mt-5 text-lg leading-relaxed text-muted">
              {tx({
                en: "It is a clinician who stays with what you are saying, explains without talking down, and does not send you out guessing. If something cannot be handled safely in this clinic, you should hear that plainly — and leave knowing where to turn.",
                es: "Es un clínico que se queda con lo que usted dice, explica sin hablarle desde arriba y no lo deja salir adivinando. Si algo no se puede atender con seguridad en esta clínica, debe escucharlo con claridad y salir sabiendo a dónde acudir.",
              })}
            </p>
            <blockquote className="mt-8 border-l-2 border-green pl-5 font-serif text-2xl leading-snug text-ink">
              {tx({
                en: "You should understand the concern, the choice in front of you, and the next step.",
                es: "Usted debe entender el problema, la decisión que tiene delante y el siguiente paso.",
              })}
            </blockquote>
            <Link to="/visit" className="group mt-8 inline-flex min-h-12 items-center gap-2 font-medium text-blue">
              {tx({ en: "See how a visit works", es: "Vea cómo funciona una visita" })}
              <span className="transition-transform duration-200 group-hover:translate-x-1" aria-hidden>
                →
              </span>
            </Link>
          </div>
        </Container>
      </section>

      <section className="border-y border-line bg-cream">
        <Container className="py-16 md:py-24">
          <div className="max-w-2xl">
            <Kicker>{tx({ en: "What we can help with", es: "En qué podemos ayudar" })}</Kicker>
            <h2 className="mt-4 font-serif text-4xl leading-tight">
              {tx({
                en: "Practical care. Confirmed before you come.",
                es: "Atención práctica. Confirmada antes de que venga.",
              })}
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-muted">
              {tx({
                en: "Services depend on staffing, eligibility, and what is available that day. Call before you visit.",
                es: "Los servicios dependen del personal, la elegibilidad y lo disponible ese día. Llame antes de venir.",
              })}
            </p>
          </div>
          <div className="mt-10 divide-y divide-line border-y border-line">
            {services.map((service, index) => (
              <Link
                key={service.title.en}
                to="/services"
                className="group grid gap-4 py-6 transition-colors duration-200 hover:bg-paper md:grid-cols-12 md:items-center md:px-2"
              >
                <span className="font-serif text-2xl text-green md:col-span-1">0{index + 1}</span>
                <span className="flex items-center gap-3 font-serif text-2xl md:col-span-4">
                  <service.icon className="size-5 text-blue" aria-hidden />
                  {tx(service.title)}
                </span>
                <span className="text-sm leading-relaxed text-muted md:col-span-6">{tx(service.body)}</span>
                <span className="hidden text-right text-muted transition-transform duration-200 group-hover:translate-x-1 md:col-span-1 md:block" aria-hidden>
                  →
                </span>
              </Link>
            ))}
          </div>
        </Container>
      </section>

      <section>
        <Container className="grid gap-12 py-16 md:py-24 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <Kicker>{tx({ en: "Become a patient", es: "Sea paciente" })}</Kicker>
            <h2 className="mt-4 font-serif text-4xl leading-tight">
              {tx({
                en: "Three steps. No medical story on this website.",
                es: "Tres pasos. Ninguna historia médica en este sitio.",
              })}
            </h2>
            <p className="mt-5 leading-relaxed text-muted">
              {tx({
                en: "Share only how to reach you. We will talk about the reason for the visit when we speak — not through an ordinary web form or email.",
                es: "Comparta solo cómo localizarle. Hablaremos del motivo de la visita cuando conversemos, no por un formulario web o un correo ordinario.",
              })}
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <RequestButton />
              <CallButton />
            </div>
          </div>
          <ol className="space-y-8 lg:col-span-7">
            {[
              {
                n: "01",
                title: { en: "Call or request a callback", es: "Llame o pida que le llamemos" },
                body: {
                  en: "Give your name, phone, a good time of day, and the language you prefer. That is enough to start.",
                  es: "Dé su nombre, teléfono, una hora conveniente y el idioma que prefiere. Con eso basta para empezar.",
                },
              },
              {
                n: "02",
                title: { en: "We confirm what is available", es: "Confirmamos qué hay disponible" },
                body: {
                  en: "The clinic tells you whether the service can be offered, what it may cost, and which papers to bring. A request is not a confirmation.",
                  es: "La clínica le dice si el servicio se puede ofrecer, qué puede costar y qué papeles traer. Una solicitud no es una confirmación.",
                },
              },
              {
                n: "03",
                title: { en: "You arrive with your questions", es: "Llega con sus preguntas" },
                body: {
                  en: "Bring identification if you have it, a medication list, and the two or three questions that matter most.",
                  es: "Traiga una identificación si la tiene, una lista de medicamentos y las dos o tres preguntas que más importan.",
                },
              },
            ].map((step) => (
              <li key={step.n} className="grid grid-cols-12 gap-4 border-t border-line pt-6">
                <span className="col-span-3 font-serif text-3xl text-green md:col-span-2">{step.n}</span>
                <div className="col-span-9 md:col-span-10">
                  <h3 className="font-serif text-2xl">{tx(step.title)}</h3>
                  <p className="mt-2 leading-relaxed text-muted">{tx(step.body)}</p>
                </div>
              </li>
            ))}
          </ol>
        </Container>
      </section>

      <section className="border-t border-line">
        <Container className="grid gap-10 py-16 md:grid-cols-12 md:py-24">
          <div className="md:col-span-5">
            <Kicker>{tx({ en: "What you can verify", es: "Lo que puede verificar" })}</Kicker>
            <h2 className="mt-4 font-serif text-4xl leading-tight md:text-5xl">
              {tx({ en: "Trust should be checkable.", es: "La confianza debe poder comprobarse." })}
            </h2>
            <p className="mt-5 max-w-sm leading-relaxed text-muted">
              {tx({
                en: "This site does not show star ratings, awards, or staff biographies. Call and ask a direct question instead.",
                es: "Este sitio no muestra calificaciones, premios ni biografías del personal. Llame y haga una pregunta directa.",
              })}
            </p>
          </div>
          <dl className="md:col-span-7">
            {[
              {
                t: { en: "Where and when", es: "Dónde y cuándo" },
                d: {
                  en: `${clinic.street}, ${clinic.city}. Monday–Friday, 9 AM–5 PM. Closed Saturday and Sunday.`,
                  es: `${clinic.street}, ${clinic.city}. Lunes a viernes, 9 AM–5 PM. Cerrado sábado y domingo.`,
                },
              },
              {
                t: { en: "National Provider Identifier", es: "Identificador nacional (NPI)" },
                d: {
                  en: `${clinic.npi}, registered as a clinic/center. You can look it up on the federal NPI registry.`,
                  es: `${clinic.npi}, registrado como clínica. Puede buscarlo en el registro federal de NPI.`,
                },
              },
              {
                t: { en: "California community clinic", es: "Clínica comunitaria de California" },
                d: {
                  en: `Listed by HCAI as an open community clinic under the former name ${clinic.former}. Facility ID ${clinic.hcaiId}.`,
                  es: `Figura en HCAI como clínica comunitaria abierta con el nombre anterior ${clinic.former}. ID de centro ${clinic.hcaiId}.`,
                },
              },
              {
                t: { en: "Nonprofit", es: "Organización sin fines de lucro" },
                d: {
                  en: `Canby Community Clinic Inc. is a 501(c)(3), EIN ${clinic.ein}, formed in 2022. Confirm tax details with the office before claiming a deduction.`,
                  es: `Canby Community Clinic Inc. es una 501(c)(3), EIN ${clinic.ein}, formada en 2022. Confirme los datos fiscales con la oficina antes de deducir un donativo.`,
                },
              },
            ].map((row) => (
              <div key={row.t.en} className="border-t border-line py-4">
                <dt className="text-xs font-medium tracking-widest text-ink uppercase">{tx(row.t)}</dt>
                <dd className="mt-2 leading-relaxed text-muted">{tx(row.d)}</dd>
              </div>
            ))}
          </dl>
        </Container>
      </section>

      <section>
        <Container className="grid gap-10 py-16 md:grid-cols-2 md:py-24">
          <div>
            <Kicker>{tx({ en: "Come to the clinic", es: "Venga a la clínica" })}</Kicker>
            <h2 className="mt-4 font-serif text-4xl">{tx({ en: "Reseda, suite 6B.", es: "Reseda, suite 6B." })}</h2>
            <p className="mt-4 leading-relaxed text-muted">
              {tx({
                en: "Allow time for parking and check-in. Call if you need help finding suite 6B. Please do not arrive expecting a walk-in emergency visit.",
                es: "Tome en cuenta el estacionamiento y el registro. Llame si necesita ayuda para encontrar la suite 6B. No venga esperando una visita de emergencia sin cita.",
              })}
            </p>
            <div className="mt-6">
              <HoursTable />
            </div>
            <a
              href={clinic.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 inline-flex min-h-12 items-center font-medium text-blue"
            >
              {tx({ en: "Directions", es: "Cómo llegar" })}
              <span className="sr-only">
                {tx({ en: ", opens in a new tab", es: ", se abre en una pestaña nueva" })}
              </span>
            </a>
          </div>
          <figure className="min-h-80 overflow-hidden border border-line bg-cream">
            <iframe
              title={tx({ en: "Map of the clinic", es: "Mapa de la clínica" })}
              src={clinic.mapsEmbed}
              className="h-80 min-h-80 w-full"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
            <figcaption className="border-t border-line px-4 py-3 text-sm text-muted">
              {clinic.street}, {clinic.city}
            </figcaption>
          </figure>
        </Container>
      </section>

      <section className="border-t border-line">
        <Container className="grid items-center gap-8 py-16 md:grid-cols-12 md:py-20">
          <Photo
            src="/media/plan.jpg"
            alt={tx({
              en: "Hands resting on a blank notepad, suggesting a simple next-step plan. Illustrative photograph.",
              es: "Manos sobre un cuaderno en blanco, como un plan sencillo de siguientes pasos. Fotografía ilustrativa.",
            })}
            className="aspect-still w-full object-cover md:col-span-5"
          />
          <div className="md:col-span-7">
            <h2 className="font-serif text-4xl leading-tight md:text-5xl">
              {tx({ en: "The fastest way in is the phone.", es: "La forma más rápida es el teléfono." })}
            </h2>
            <p className="mt-4 max-w-xl text-lg leading-relaxed text-muted">
              {tx({
                en: `Call ${clinic.phoneDisplay} on a weekday between 9 and 5. If you would rather we call you, send only your contact details.`,
                es: `Llame al ${clinic.phoneDisplay} de lunes a viernes, entre las 9 y las 5. Si prefiere que le llamemos, envíe solo sus datos de contacto.`,
              })}
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <CallButton variant="primary" />
              <RequestButton variant="secondary" />
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
