import { createFileRoute } from "@tanstack/react-router";
import { GivePage } from "@/routes/give";

export const Route = createFileRoute("/donate")({
  head: () => ({
    meta: [
      { title: "Donate | Canby Community Clinic" },
      {
        name: "description",
        content:
          "Donate to Canby Community Clinic. Tell the office an amount and what you hope to support. This website does not charge a card.",
      },
    ],
  }),
  component: GivePage,
});
