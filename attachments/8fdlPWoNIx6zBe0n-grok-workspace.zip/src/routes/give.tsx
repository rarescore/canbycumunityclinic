import { createFileRoute } from "@tanstack/react-router";
import { clinic } from "@/lib/clinic";
import { DonateForm } from "@/components/site/forms";
import { useTx } from "@/components/site/i18n";
import { Container, PageIntro } from "@/components/site/ui";

export const Route = createFileRoute("/give")({
  head: () => ({
    meta: [
      { title: "Donate | Canby Community Clinic" },
      {
        name: "description",
        content:
          "Donate to Canby Community Clinic. Tell the office an amount and what you hope to support. This website does not charge a card.",
      },
    ],
  }),
  component: GivePage,
});

export function GivePage() {
  const { tx } = useTx();
  return (
    <>
      <PageIntro
        kicker={tx({ en: "Donate", es: "Donar" })}
        title={tx({
          en: "A gift with a name, not a checkout button.",
          es: "Un donativo con nombre, no un botón de pago.",
        })}
        lede={tx({
          en: "Supplies, medications, education, and the cost of staying open. Say what you have in mind. The office confirms the legal payee before any money moves. Nothing on this page charges a card.",
          es: "Insumos, medicamentos, educación y el costo de seguir abiertos. Diga lo que tiene en mente. La oficina confirma el beneficiario legal antes de que se mueva dinero. Nada en esta página cobra una tarjeta.",
        })}
      />
      <Container className="grid gap-10 py-12 md:grid-cols-12 md:py-16">
        <div className="md:col-span-5">
          <p className="text-sm leading-relaxed text-muted">
            {tx({
              en: `Canby Community Clinic Inc. is a 501(c)(3), EIN ${clinic.ein}. Confirm the legal name and current tax status with the office before you claim a deduction.`,
              es: `Canby Community Clinic Inc. es una 501(c)(3), EIN ${clinic.ein}. Confirme el nombre legal y la situación fiscal con la oficina antes de deducir un donativo.`,
            })}
          </p>
          <div className="mt-6 border border-line bg-cream p-5">
            <h2 className="font-serif text-2xl">{tx({ en: "After the office replies", es: "Después de que responda la oficina" })}</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted">
              {tx({
                en: "Checks, once the payee is confirmed, can be mailed to:",
                es: "Los cheques, una vez confirmado el beneficiario, pueden enviarse a:",
              })}
            </p>
            <p className="mt-3 font-medium">
              {clinic.name}
              <br />
              {clinic.street}
              <br />
              {clinic.city}
            </p>
            <a className="mt-4 inline-flex min-h-11 items-center font-medium text-blue" href={`mailto:${clinic.emailOffice}`}>
              {clinic.emailOffice}
            </a>
          </div>
        </div>
        <div className="rounded-lg border border-line bg-cream p-5 md:col-span-7 md:p-8">
          <DonateForm />
        </div>
      </Container>
    </>
  );
}
